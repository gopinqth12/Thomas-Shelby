        // ---------------------------------------------------------------- user interface

        void BuildUi()
        {
            Panel hdr = new Panel();
            hdr.Dock = DockStyle.Top;
            hdr.Height = 64;
            hdr.Tag = "panel";

            Label title = new Label();
            title.Text = "Flash Tool";
            title.Font = new Font("Segoe UI Semibold", 16f);
            title.AutoSize = true;
            title.Location = new Point(18, 5);

            Label sub = new Label();
            sub.Text = "v" + Version + "  by Thomus Shelby";
            sub.Tag = "muted";
            sub.AutoSize = true;
            sub.Location = new Point(21, 39);

            FlowLayoutPanel st = new FlowLayoutPanel();
            st.Dock = DockStyle.Right;
            st.AutoSize = true;
            st.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            st.WrapContents = false;
            st.Padding = new Padding(0, 18, 14, 0);
            _stT = StatusLabel();
            _stA = StatusLabel();
            _stF = StatusLabel();
            Button recheck = Btn("Recheck", null, (s, e) => UpdateToolStatus());
            recheck.MinimumSize = new Size(76, 28);
            recheck.Margin = new Padding(6, 0, 0, 0);
            st.Controls.Add(_stT);
            st.Controls.Add(_stA);
            st.Controls.Add(_stF);
            st.Controls.Add(recheck);
            hdr.Controls.Add(st);
            hdr.Controls.Add(title);
            hdr.Controls.Add(sub);

            Panel nav = new Panel();
            nav.Dock = DockStyle.Left;
            nav.Width = 178;
            nav.Tag = "panel";
            nav.Padding = new Padding(0, 10, 0, 0);
            string[] names = new string[] { "MediaTek", "Fastboot / GSI", "Debloat", "Logs", "Appearance" };
            _navBtns = new Button[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                Button b = new Button();
                b.Text = "   " + names[i];
                b.Tag = "nav";
                b.Height = 46;
                b.Dock = DockStyle.Top;
                b.TextAlign = ContentAlignment.MiddleLeft;
                b.Cursor = Cursors.Hand;
                b.Font = new Font("Segoe UI", 10.5f);
                int idx = i;
                b.Click += (s, e) => ShowPage(idx);
                _navBtns[i] = b;
            }
            for (int i = names.Length - 1; i >= 0; i--) nav.Controls.Add(_navBtns[i]);

            _pageHost = new Panel();
            _pageHost.Dock = DockStyle.Top;
            _pageHost.Height = 420;
            _pageHost.Tag = "bg";
            _pages = new Panel[] { BuildMtk(), BuildFb(), BuildDeb(), BuildLogs(), BuildAppearance() };
            foreach (Panel pg in _pages) _pageHost.Controls.Add(pg);

            _log = new RichTextBox();
            _log.Dock = DockStyle.Fill;
            _log.ReadOnly = true;
            _log.BorderStyle = BorderStyle.None;
            _log.WordWrap = true;
            _log.DetectUrls = false;
            _log.HideSelection = false;
            Panel logWrap = new Panel();
            logWrap.Dock = DockStyle.Fill;
            logWrap.Tag = "input";
            logWrap.Padding = new Padding(14, 8, 8, 12);
            logWrap.Controls.Add(_log);

            Panel logBar = new Panel();
            logBar.Dock = DockStyle.Top;
            logBar.Height = 42;
            logBar.Tag = "panel";
            _lblOp = new Label();
            _lblOp.Dock = DockStyle.Fill;
            _lblOp.TextAlign = ContentAlignment.MiddleLeft;
            _lblOp.Padding = new Padding(14, 0, 0, 0);
            _lblOp.Font = new Font("Segoe UI Semibold", 9.5f);
            _lblOp.Text = "Ready";
            FlowLayoutPanel lb = new FlowLayoutPanel();
            lb.Dock = DockStyle.Right;
            lb.AutoSize = true;
            lb.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            lb.WrapContents = false;
            lb.Padding = new Padding(0, 7, 10, 0);
            _btnStop = Btn("Stop", "danger", (s, e) => OnStop());
            _btnStop.Enabled = false;
            Button bClear = Btn("Clear", null, (s, e) => { _log.Clear(); _progStart = -1; });
            Button bCopy = Btn("Copy", null, (s, e) => CopyLog());
            foreach (Button x in new Button[] { _btnStop, bClear, bCopy })
            {
                x.MinimumSize = new Size(74, 28);
                x.Margin = new Padding(6, 0, 0, 0);
                lb.Controls.Add(x);
            }
            logBar.Controls.Add(_lblOp);
            logBar.Controls.Add(lb);

            _bar = new ProgressBar();
            _bar.Dock = DockStyle.Top;
            _bar.Height = 3;
            _bar.Style = ProgressBarStyle.Marquee;
            _bar.MarqueeAnimationSpeed = 30;
            _bar.Visible = false;

            Panel logPanel = new Panel();
            logPanel.Dock = DockStyle.Fill;
            logPanel.Controls.Add(logWrap);
            logPanel.Controls.Add(logBar);
            logPanel.Controls.Add(_bar);

            Panel content = new Panel();
            content.Dock = DockStyle.Fill;
            content.Controls.Add(logPanel);
            content.Controls.Add(_pageHost);

            Controls.Add(content);
            Controls.Add(nav);
            Controls.Add(hdr);

            _tick = new System.Windows.Forms.Timer();
            _tick.Interval = 500;
            _tick.Tick += (s, e) => UpdateElapsed();
        }

        Label StatusLabel()
        {
            Label l = new Label();
            l.AutoSize = true;
            l.Margin = new Padding(0, 6, 18, 0);
            l.Font = new Font("Segoe UI Semibold", 9.5f);
            return l;
        }

        Panel NewPage()
        {
            Panel p = new Panel();
            p.Dock = DockStyle.Fill;
            p.AutoScroll = true;
            p.Padding = new Padding(18, 14, 18, 8);
            p.Visible = false;
            return p;
        }

        TableLayoutPanel NewTable()
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.AutoSize = true;
            t.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            t.ColumnCount = 3;
            t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            t.RowCount = 0;
            return t;
        }

        FlowLayoutPanel NewFlow()
        {
            FlowLayoutPanel f = new FlowLayoutPanel();
            f.AutoSize = true;
            f.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            f.WrapContents = true;
            f.FlowDirection = FlowDirection.LeftToRight;
            f.Padding = new Padding(0, 4, 0, 0);
            return f;
        }

        // Stacks controls top to bottom in the order given (docked controls are laid out last-added first).
        void Stack(Panel page, params Control[] items)
        {
            for (int i = items.Length - 1; i >= 0; i--)
            {
                items[i].Dock = DockStyle.Top;
                page.Controls.Add(items[i]);
            }
        }

        Label Cap(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.Tag = "muted";
            l.AutoSize = true;
            l.Padding = new Padding(0, 12, 0, 4);
            l.Font = new Font("Segoe UI Semibold", 9f);
            return l;
        }

        Label Heading(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Font = new Font("Segoe UI Semibold", 12.5f);
            l.Padding = new Padding(0, 0, 0, 6);
            return l;
        }

        Label Note(string text, int height)
        {
            Label l = new Label();
            l.Text = text;
            l.Tag = "muted";
            l.AutoSize = false;
            l.Height = height;
            l.Padding = new Padding(0, 6, 0, 0);
            return l;
        }

        // role: null = plain, "write" = accent border (writes to the device), "danger" = red border (erases data / flashes firmware)
        Button Btn(string text, string role, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.Tag = role;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.MinimumSize = new Size(150, 34);
            b.Padding = new Padding(10, 0, 10, 0);
            b.Margin = new Padding(0, 0, 8, 8);
            b.FlatStyle = FlatStyle.Flat;
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.Click += click;
            return b;
        }

        TextBox Row(TableLayoutPanel table, string label, string filter, bool folder)
        {
            int r = table.RowCount;
            table.RowCount = r + 1;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label l = new Label();
            l.Text = label;
            l.AutoSize = true;
            l.Anchor = AnchorStyles.Left;
            l.Margin = new Padding(0, 6, 14, 6);
            TextBox tb = new TextBox();
            tb.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            tb.Margin = new Padding(0, 4, 0, 4);
            tb.AllowDrop = true;
            TextBox box = tb;
            tb.DragEnter += (s, e) =>
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
            };
            tb.DragDrop += (s, e) =>
            {
                string[] dropped = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (dropped != null && dropped.Length > 0) box.Text = dropped[0];
            };
            table.Controls.Add(l, 0, r);
            table.Controls.Add(tb, 1, r);
            if (filter != null || folder)
            {
                string flt = filter;
                bool fol = folder;
                Button b = new Button();
                b.Text = "Browse...";
                b.AutoSize = true;
                b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                b.MinimumSize = new Size(90, 28);
                b.Anchor = AnchorStyles.Left;
                b.Margin = new Padding(8, 2, 0, 2);
                b.FlatStyle = FlatStyle.Flat;
                b.Cursor = Cursors.Hand;
                b.UseVisualStyleBackColor = false;
                b.Click += (s, e) => Browse(box, flt, fol);
                table.Controls.Add(b, 2, r);
            }
            return tb;
        }

        void RowCtl(TableLayoutPanel table, string label, Control c)
        {
            int r = table.RowCount;
            table.RowCount = r + 1;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label l = new Label();
            l.Text = label;
            l.AutoSize = true;
            l.Anchor = AnchorStyles.Left;
            l.Margin = new Padding(0, 6, 14, 6);
            c.Anchor = AnchorStyles.Left;
            c.Margin = new Padding(0, 4, 0, 4);
            table.Controls.Add(l, 0, r);
            table.Controls.Add(c, 1, r);
        }

        void Browse(TextBox tb, string filter, bool folder)
        {
            string cur = tb.Text.Trim();
            if (folder)
            {
                using (FolderBrowserDialog d = new FolderBrowserDialog())
                {
                    d.Description = "Select folder";
                    if (cur.Length > 0 && Directory.Exists(cur)) d.SelectedPath = cur;
                    if (d.ShowDialog(this) == DialogResult.OK) tb.Text = d.SelectedPath;
                }
            }
            else
            {
                using (OpenFileDialog d = new OpenFileDialog())
                {
                    d.Filter = filter;
                    try
                    {
                        string dir = cur.Length > 0 ? Path.GetDirectoryName(cur) : null;
                        if (dir != null && Directory.Exists(dir)) d.InitialDirectory = dir;
                    }
                    catch (Exception) { }
                    if (d.ShowDialog(this) == DialogResult.OK) tb.Text = d.FileName;
                }
            }
        }

        // ---------------------------------------------------------------- pages

        Panel BuildMtk()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();
            _tbDA = Row(t, "DA file (DA_BR.bin)", "DA file (*.bin)|*.bin|All files|*.*", false);
            _tbAuth = Row(t, "Auth file (optional)", "Auth file (*.auth)|*.auth|All files|*.*", false);
            _tbPart = Row(t, "Partition name", null, false);
            _tbBackup = Row(t, "Backup folder", null, true);
            _tbImg = Row(t, "Image to write", "Image (*.img;*.bin)|*.img;*.bin|All files|*.*", false);
            _tbScatter = Row(t, "Scatter file (.xml)", "Scatter (*.xml)|*.xml|All files|*.*", false);
            _tbPreloader = Row(t, "Preloader (.bin)", "Preloader (*.bin)|*.bin|All files|*.*", false);

            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Check partitions", null, (s, e) => OpPgpt()));
            f.Controls.Add(Btn("Read all partitions", null, (s, e) => OpReadAll()));
            f.Controls.Add(Btn("Read partition", null, (s, e) => OpRead()));
            f.Controls.Add(Btn("Write partition", "danger", (s, e) => OpWrite()));
            f.Controls.Add(Btn("Firmware upgrade", "danger", (s, e) => OpScatter()));
            f.Controls.Add(Btn("Erase partition", "danger", (s, e) => OpErase()));
            f.Controls.Add(Btn("Reboot", null, (s, e) => OpReboot()));
            Stack(p, t, Cap("Operations"), f,
                Note("Each operation uses only the fields it needs. Accent border: writes to the device. Red border: erases data or flashes firmware. You can drop files onto the fields.", 44));
            return p;
        }

        Panel BuildFb()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();
            _tbVbmeta = Row(t, "vbmeta.img (stock)", ImgFilter, false);
            _tbEmpty = Row(t, "empty_partition.img", ImgFilter, false);
            _tbGsi = Row(t, "GSI system image", ImgFilter, false);
            _tbBoot = Row(t, "Root (patched boot) image", ImgFilter, false);
            _cbMethod = new ComboBox();
            _cbMethod.DropDownStyle = ComboBoxStyle.DropDownList;
            _cbMethod.FlatStyle = FlatStyle.Flat;
            _cbMethod.Width = 220;
            _cbMethod.Items.Add("ADB (recommended)");
            _cbMethod.Items.Add("Fastboot");
            _cbMethod.SelectedIndex = 0;
            RowCtl(t, "Reboot to bootloader via", _cbMethod);

            FlowLayoutPanel f1 = NewFlow();
            f1.Controls.Add(Btn("Detect devices", null, (s, e) => OpDetect()));
            f1.Controls.Add(Btn("Reboot to bootloader", null, (s, e) => OpRebootBl()));
            f1.Controls.Add(Btn("Unlock bootloader", "danger", (s, e) => OpLock(true)));
            f1.Controls.Add(Btn("Relock bootloader", "danger", (s, e) => OpLock(false)));
            FlowLayoutPanel f2 = NewFlow();
            f2.Controls.Add(Btn("Install GSI", "danger", (s, e) => OpGsi()));
            f2.Controls.Add(Btn("Install root image", "write", (s, e) => OpRoot()));
            f2.Controls.Add(Btn("Disable verity", "write", (s, e) => OpVerity()));
            f2.Controls.Add(Btn("Automated root", "write", (s, e) => OpAutoRoot()));
            FlowLayoutPanel f3 = NewFlow();
            f3.Controls.Add(Btn("Set slot A", "write", (s, e) => OpSlot("a")));
            f3.Controls.Add(Btn("Set slot B", "write", (s, e) => OpSlot("b")));
            f3.Controls.Add(Btn("Check slot", null, (s, e) => OpSlotCheck()));
            f3.Controls.Add(Btn("Reboot device", null, (s, e) => OpFbReboot()));
            Stack(p, t, Cap("Device and bootloader"), f1, Cap("Flash"), f2, Cap("Active slot (A / B)"), f3);
            return p;
        }

        Panel BuildDeb()
        {
            Panel p = NewPage();
            _lblDeb = new Label();
            _lblDeb.AutoSize = true;
            _lblDeb.Padding = new Padding(0, 4, 0, 8);
            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Scan phone", null, (s, e) => OpScan()));
            f.Controls.Add(Btn("Safe remove", "write", (s, e) => OpDebloat("SAFE")));
            f.Controls.Add(Btn("All-in-one remove", "danger", (s, e) => OpDebloat("ALL")));
            f.Controls.Add(Btn("Restore", null, (s, e) => OpDebloat("RESTORE")));
            Stack(p, Heading("Transsion debloat (ADB)"),
                Note("Enable Developer options and USB debugging on the phone first, then tap Allow when the phone asks. Removal keeps app data, and Restore brings the listed apps back.", 48),
                _lblDeb, f,
                Note("Safe remove skips apps that features depend on. All-in-one remove also removes the keyboard, file manager, browser, Phone Master / Manager, cloud, weather, Google app and Photos.", 48));
            SetDebCounts(null);
            return p;
        }

        Panel BuildLogs()
        {
            Panel p = NewPage();
            _lblFolder = new Label();
            _lblFolder.AutoSize = true;
            _lblFolder.Tag = "accent";
            _lblFolder.Padding = new Padding(0, 6, 0, 10);
            ShowLogFolder();
            _chkAsk = new CheckBox();
            _chkAsk.Text = "Ask for a folder after every operation";
            _chkAsk.AutoSize = true;
            _chkAsk.Checked = _askLog;
            _chkAsk.Padding = new Padding(0, 8, 0, 0);
            _chkAsk.CheckedChanged += (s, e) =>
            {
                if (_loading) return;
                _askLog = _chkAsk.Checked;
                SaveSettings();
            };
            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Change folder", null, (s, e) => ChangeLogFolder()));
            f.Controls.Add(Btn("Open folder", null, (s, e) => OpenLogFolder()));
            f.Controls.Add(Btn("Reset to default", null, (s, e) => ResetLogFolder()));
            f.Controls.Add(Btn("Open last log", null, (s, e) => OpenLastLog()));
            Stack(p, Heading("Logs and screenshots"),
                Note("After every flashing operation the tool saves two screenshots of this window and the whole output as a text log.", 44),
                _lblFolder, f, _chkAsk);
            return p;
        }

        Panel BuildAppearance()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();

            _cbTheme = new ComboBox();
            _cbTheme.DropDownStyle = ComboBoxStyle.DropDownList;
            _cbTheme.FlatStyle = FlatStyle.Flat;
            _cbTheme.Width = 240;
            foreach (Theme th in _themes) _cbTheme.Items.Add(th.Name);
            _cbTheme.Items.Add("Custom");
            _cbTheme.SelectedIndex = (_themeIdx >= 0 && _themeIdx <= _themes.Count) ? _themeIdx : 0;
            _cbTheme.SelectedIndexChanged += (s, e) =>
            {
                if (_loading) return;
                _themeIdx = _cbTheme.SelectedIndex;
                ApplyTheme();
                SaveSettings();
            };
            RowCtl(t, "Theme", _cbTheme);

            FlowLayoutPanel cf = NewFlow();
            cf.Padding = new Padding(0);
            string[] cn = new string[] { "Background...", "Text...", "Accent..." };
            for (int i = 0; i < cn.Length; i++)
            {
                int which = i;
                Button cb = Btn(cn[i], null, (s, e) => PickCustom(which));
                cb.MinimumSize = new Size(110, 28);
                _custBtns.Add(cb);
                cf.Controls.Add(cb);
            }
            RowCtl(t, "Custom colors", cf);

            _cbFont = new ComboBox();
            _cbFont.DropDownStyle = ComboBoxStyle.DropDown;
            _cbFont.FlatStyle = FlatStyle.Flat;
            _cbFont.Width = 240;
            string[] pref = new string[] { "Consolas", "Cascadia Mono", "Cascadia Code", "Lucida Console", "Courier New", "Segoe UI" };
            HashSet<string> have = new HashSet<string>();
            foreach (FontFamily ff in FontFamily.Families) have.Add(ff.Name);
            foreach (string fn in pref)
            {
                if (have.Contains(fn)) _cbFont.Items.Add(fn);
            }
            _cbFont.Text = _logFont;
            _cbFont.SelectedIndexChanged += (s, e) => ChangeLogFont();
            _cbFont.Leave += (s, e) => ChangeLogFont();
            RowCtl(t, "Output font", _cbFont);

            _numSize = new NumericUpDown();
            _numSize.Minimum = 8;
            _numSize.Maximum = 28;
            _numSize.Width = 70;
            _numSize.Value = (decimal)Math.Max(8.0, Math.Min(28.0, Math.Round((double)_logSize)));
            _numSize.ValueChanged += (s, e) => ChangeLogFont();
            RowCtl(t, "Output font size", _numSize);

            Stack(p, Heading("Appearance"), t,
                Note("The theme and the font apply to this window and to the output area.", 36));
            return p;
        }

        void ChangeLogFont()
        {
            if (_loading) return;
            string n = _cbFont.Text.Trim();
            if (n.Length > 0) _logFont = n;
            _logSize = (float)_numSize.Value;
            ApplyLogFont();
            SaveSettings();
        }

        void PickCustom(int which)
        {
            using (ColorDialog d = new ColorDialog())
            {
                d.FullOpen = true;
                d.Color = which == 0 ? _custBg : (which == 1 ? _custFg : _custAcc);
                if (d.ShowDialog(this) != DialogResult.OK) return;
                if (which == 0) _custBg = d.Color;
                else if (which == 1) _custFg = d.Color;
                else _custAcc = d.Color;
            }
            if (_themeIdx >= _themes.Count) ApplyTheme();
            SaveSettings();
        }

