// Flash Tool GUI v2.1 - Windows Forms front end for flash_tool_V2_1.bat
// Plain C# 5, so the compiler built into Windows (csc.exe, .NET Framework 4.x) can build it.
// Build it with build_gui.bat -> gui.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace FlashToolGui
{
    static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main()
        {
            try { SetProcessDPIAware(); } catch (Exception) { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    class Theme
    {
        public string Name;
        public Color Bg, Panel, Input, Fg, Muted, Accent;

        public Theme(string name, string bg, string panel, string input, string fg, string muted, string accent)
        {
            Name = name; Bg = H(bg); Panel = H(panel); Input = H(input);
            Fg = H(fg); Muted = H(muted); Accent = H(accent);
        }

        public static Color H(string hex) { return ColorTranslator.FromHtml("#" + hex); }
    }

    class DbItem
    {
        public string Cat;
        public string Pkg;
        public bool Aio;
    }

    class Part
    {
        public string Name = "";
        public string Img = "";
        public string OpName = "";
        public bool Dl = true;
        public int FileLine = -1;
        public int DlLine = -1;
    }

    class MainForm : Form
    {
        const string Version = "2.1";
        const string ImgFilter = "Image (*.img)|*.img|All files|*.*";

        // Transsion debloat list. "#" starts a category, "+" marks apps that only the all-in-one remove touches.
        const string DbList = @"
#Assistants / AI
com.transsion.aivoiceassistant
com.transsion.folax
com.transsion.kolun.assistant
+com.transsion.tranvoicecommand
+com.transsion.smartrecognition
#Ads / promo / recommendation / telemetry
com.transsion.magazinelockscreen
com.transsion.magazineservice.xos
com.transsion.mtimes
com.transsion.personalizedService.xos
+com.transsion.tranengine
com.transsion.statisticalsales
+com.transsion.succ
com.transsion.wezone
+com.transsion.mol
com.idea.questionnaire
com.transsion.chromecustomization
com.android.google.adservices.api
#App stores / updaters / push
com.transsnet.store
net.bat.store
com.transsion.plat.appupdate
com.talpa.hiservice
com.transsion.gamecenter
com.transsion.themeshop
#Cleaners / utilities
+com.transsion.phonemaster
+com.transsion.phonemanager
+com.transsion.applock
com.transsion.agingfunction
com.transsion.manualguide
com.transsion.repaircard
com.transsion.carlcare
com.transsion.globalsearch
+com.transsion.scanningrecharger
com.transsion.health
+com.rlk.weathers
com.zaz.translate
+com.mediatek.mdmconfig
com.transsion.tips
+com.transsion.filemanagerx
+com.transsion.dualapp
+com.xui.xhide
+com.transsion.tranfacicon
+com.geniex.vsimhelper
#Transfer / sharing / connect
com.transsion.mobilecloner
com.transsion.letswitch
+com.transsion.cloudserver
com.transsion.pcconnect
com.talpa.share
com.transsion.wifiplaytogether
+com.transsion.audiosmartconnect
+tech.palm.find
#Launcher / browser / keyboard / media
com.talpa.hibrowser
+com.facemoji.lite.transsion
com.transsion.videoplayer.overseas
com.google.android.apps.nbu.files
com.transsion.magicshow
com.trassion.infinix.xclub
+com.android.chrome
+com.funbase.xradio
#Wallpapers / kids mode
com.transsion.livewallpaper.mecha
com.transsion.livewallpaper.saibo
com.transsion.livewallpaper.airship
com.transsion.livewallpaper.spacecraft
com.transsion.livewallpaper.pictorial
com.transsion.childmode
com.transsion.childmode.resoverlay
#Facebook / Google extras
com.facebook.services
com.facebook.appmanager
com.facebook.system
com.google.android.feedback
com.google.android.projection.gearhead
com.google.android.videos
com.google.android.apps.youtube.music
com.google.android.apps.tachyon
com.google.android.apps.wellbeing
com.google.android.gms.location.history
com.android.hotwordenrollment.xgoogle
com.android.hotwordenrollment.okgoogle
+com.google.android.apps.photos
+com.google.android.googlequicksearchbox
+com.google.android.healthconnect.controller
";

        static readonly Regex Ansi = new Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]");

        readonly string _appDir = AppDomain.CurrentDomain.BaseDirectory;
        readonly string _iniPath;
        readonly List<DbItem> _db = ParseDb();

        List<Theme> _themes;
        Theme _t;
        int _themeIdx;
        Color _custBg = Color.FromArgb(18, 20, 23);
        Color _custFg = Color.FromArgb(216, 220, 225);
        Color _custAcc = Color.FromArgb(92, 200, 224);
        Color _green, _red, _yel;
        string _logFont = "Consolas";
        float _logSize = 10f;
        string _logFolder;
        bool _askLog;
        bool _loading = true;
        string _savedDA = "";
        string _savedAuth = "";

        // controls
        RichTextBox _log;
        Label _lblOp, _lblDeb, _lblFolder, _stT, _stA, _stF;
        Button _btnStop;
        ProgressBar _bar;
        Panel _pageHost;
        Panel[] _pages;
        Button[] _navBtns;
        int _page;
        TextBox _tbDA, _tbAuth, _tbPart, _tbBackup, _tbImg, _tbScatter, _tbPreloader;
        TextBox _tbVbmeta, _tbEmpty, _tbGsi, _tbBoot;
        ComboBox _cbMethod, _cbTheme, _cbFont;
        NumericUpDown _numSize;
        CheckBox _chkAsk;
        List<Button> _custBtns = new List<Button>();
        System.Windows.Forms.Timer _tick;

        // running job
        volatile bool _busy;
        volatile bool _cancel;
        Process _proc;
        Stopwatch _sw;
        string _opName = "";
        string _opDesc = "";
        int _opRes;
        bool _opSave;
        DateTime _opStart;
        string _bmName = "";
        int _progStart = -1;

        public MainForm()
        {
            _iniPath = Path.Combine(_appDir, "flash_tool_gui.ini");
            _logFolder = Path.Combine(_appDir, "flash_logs");
            InitThemes();
            LoadSettings();
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = new Font("Segoe UI", 9.5f);
            Text = "Flash Tool v" + Version + " - by Thomus Shelby";
            ClientSize = new Size(1100, 800);
            MinimumSize = new Size(920, 660);
            StartPosition = FormStartPosition.CenterScreen;
            BuildUi();
            _tbDA.Text = _savedDA;
            _tbAuth.Text = _savedAuth;
            _loading = false;
            ApplyTheme();
            ShowPage(0);
            Shown += OnShown;
        }

        void OnShown(object sender, EventArgs e)
        {
            Rectangle wa = Screen.FromControl(this).WorkingArea;
            if (Width > wa.Width) Width = wa.Width;
            if (Height > wa.Height) Height = wa.Height;
            CenterToScreen();
            UpdateToolStatus();
            Welcome();
        }

        // ---------------------------------------------------------------- themes and settings

        void InitThemes()
        {
            _themes = new List<Theme>();
            _themes.Add(new Theme("Classic Dark", "121417", "1B1F24", "0D0F12", "D8DCE1", "7D8793", "5CC8E0"));
            _themes.Add(new Theme("Hacker Green", "050B07", "0B140D", "030604", "3CE462", "23904A", "86FFA3"));
            _themes.Add(new Theme("Ocean Blue", "0B2545", "12355F", "081D38", "EAF2FF", "8FB0D9", "FFD166"));
            _themes.Add(new Theme("Midnight Purple", "1A1033", "26184B", "120A26", "EDE7FF", "A594D6", "F5C84C"));
            _themes.Add(new Theme("Amber Terminal", "140D00", "201603", "0E0900", "FFB000", "A8740A", "FFE08A"));
            _themes.Add(new Theme("Crimson", "17080A", "240E11", "100506", "F2D4D6", "A3686C", "FF5A64"));
            _themes.Add(new Theme("Light Pro", "F1F3F5", "FFFFFF", "FFFFFF", "1F2933", "69747F", "1D5FD1"));
            _themes.Add(new Theme("Slate Gray", "2B3036", "363C44", "23272C", "EEF1F4", "9AA5B1", "F5C84C"));
            _themes.Add(new Theme("Cyber Cyan", "020E10", "07191D", "010809", "5CF0F0", "2E9C9C", "F2FFFF"));
        }

        Theme CurrentTheme()
        {
            if (_themeIdx >= 0 && _themeIdx < _themes.Count) return _themes[_themeIdx];
            Theme c = new Theme("Custom", "000000", "000000", "000000", "000000", "000000", "000000");
            c.Bg = _custBg;
            c.Fg = _custFg;
            c.Accent = _custAcc;
            c.Panel = Blend(_custBg, _custFg, 0.07);
            c.Input = Blend(_custBg, Color.Black, 0.25);
            c.Muted = Blend(_custFg, _custBg, 0.5);
            return c;
        }

        static Color Blend(Color a, Color b, double amount)
        {
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * amount),
                (int)(a.G + (b.G - a.G) * amount),
                (int)(a.B + (b.B - a.B) * amount));
        }

        static double Lum(Color c)
        {
            return (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) / 255.0;
        }

        static Color ParseHex(string v, Color def)
        {
            try { return ColorTranslator.FromHtml("#" + v.TrimStart('#')); }
            catch (Exception) { return def; }
        }

        static string Hex(Color c)
        {
            return string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);
        }

        void LoadSettings()
        {
            try
            {
                if (!File.Exists(_iniPath)) return;
                foreach (string raw in File.ReadAllLines(_iniPath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line[0] == '#') continue;
                    int eq = line.IndexOf('=');
                    if (eq < 1) continue;
                    string k = line.Substring(0, eq).Trim().ToUpperInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    int n;
                    float f;
                    switch (k)
                    {
                        case "THEME":
                            if (int.TryParse(v, out n) && n >= 0 && n <= _themes.Count) _themeIdx = n;
                            break;
                        case "CUSTBG": _custBg = ParseHex(v, _custBg); break;
                        case "CUSTFG": _custFg = ParseHex(v, _custFg); break;
                        case "CUSTACCENT": _custAcc = ParseHex(v, _custAcc); break;
                        case "LOGFONT":
                            if (v.Length > 0) _logFont = v;
                            break;
                        case "LOGFONTSIZE":
                            if (float.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out f) && f >= 8 && f <= 28) _logSize = f;
                            break;
                        case "LOGFOLDER":
                            if (v.Length > 0) _logFolder = v;
                            break;
                        case "ASKLOG": _askLog = (v == "1"); break;
                        case "DA": _savedDA = v; break;
                        case "AUTH": _savedAuth = v; break;
                    }
                }
            }
            catch (Exception) { }
        }

        void SaveSettings()
        {
            if (_loading) return;
            try
            {
                List<string> l = new List<string>();
                l.Add("# flash tool gui settings");
                l.Add("THEME=" + _themeIdx);
                l.Add("CUSTBG=" + Hex(_custBg));
                l.Add("CUSTFG=" + Hex(_custFg));
                l.Add("CUSTACCENT=" + Hex(_custAcc));
                l.Add("LOGFONT=" + _logFont);
                l.Add("LOGFONTSIZE=" + _logSize.ToString(CultureInfo.InvariantCulture));
                l.Add("LOGFOLDER=" + _logFolder);
                l.Add("ASKLOG=" + (_askLog ? "1" : "0"));
                l.Add("DA=" + _tbDA.Text.Trim());
                l.Add("AUTH=" + _tbAuth.Text.Trim());
                File.WriteAllLines(_iniPath, l.ToArray(), new UTF8Encoding(false));
            }
            catch (Exception) { }
        }

        static List<DbItem> ParseDb()
        {
            List<DbItem> list = new List<DbItem>();
            string cat = "";
            foreach (string raw in DbList.Split('\n'))
            {
                string s = raw.Trim();
                if (s.Length == 0) continue;
                if (s[0] == '#') { cat = s.Substring(1); continue; }
                DbItem it = new DbItem();
                it.Cat = cat;
                if (s[0] == '+') { it.Aio = true; s = s.Substring(1); }
                it.Pkg = s;
                list.Add(it);
            }
            return list;
        }

        // ---------------------------------------------------------------- user interface

        void BuildUi()
        {
            Panel hdr = new Panel();
            hdr.Dock = DockStyle.Top;
            hdr.Height = 64;
            hdr.Tag = "panel";

            Label title = new Label();
            title.Text = "Flash Tool";
            title.Font = new Font("Segoe UI Semibold", 16f);
            title.AutoSize = true;
            title.Location = new Point(18, 5);

            Label sub = new Label();
            sub.Text = "v" + Version + "  by Thomus Shelby";
            sub.Tag = "muted";
            sub.AutoSize = true;
            sub.Location = new Point(21, 39);

            FlowLayoutPanel st = new FlowLayoutPanel();
            st.Dock = DockStyle.Right;
            st.AutoSize = true;
            st.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            st.WrapContents = false;
            st.Tag = "panel";
            st.Padding = new Padding(0, 18, 14, 0);
            _stT = StatusLabel();
            _stA = StatusLabel();
            _stF = StatusLabel();
            Button recheck = Btn("Recheck", null, (s, e) => UpdateToolStatus());
            recheck.MinimumSize = new Size(76, 28);
            recheck.Margin = new Padding(6, 0, 0, 0);
            st.Controls.Add(_stT);
            st.Controls.Add(_stA);
            st.Controls.Add(_stF);
            st.Controls.Add(recheck);
            hdr.Controls.Add(st);
            hdr.Controls.Add(title);
            hdr.Controls.Add(sub);

            Panel nav = new Panel();
            nav.Dock = DockStyle.Left;
            nav.Width = 178;
            nav.Tag = "panel";
            nav.Padding = new Padding(0, 10, 0, 0);
            string[] names = new string[] { "MediaTek", "Fastboot / GSI", "Debloat", "Logs", "Appearance" };
            _navBtns = new Button[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                Button b = new Button();
                b.Text = "   " + names[i];
                b.Tag = "nav";
                b.Height = 46;
                b.Dock = DockStyle.Top;
                b.TextAlign = ContentAlignment.MiddleLeft;
                b.Cursor = Cursors.Hand;
                b.Font = new Font("Segoe UI", 10.5f);
                int idx = i;
                b.Click += (s, e) => ShowPage(idx);
                _navBtns[i] = b;
            }
            for (int i = names.Length - 1; i >= 0; i--) nav.Controls.Add(_navBtns[i]);

            _pageHost = new Panel();
            _pageHost.Dock = DockStyle.Top;
            _pageHost.Height = 420;
            _pageHost.Tag = "bg";
            _pages = new Panel[] { BuildMtk(), BuildFb(), BuildDeb(), BuildLogs(), BuildAppearance() };
            foreach (Panel pg in _pages) _pageHost.Controls.Add(pg);

            _log = new RichTextBox();
            _log.Dock = DockStyle.Fill;
            _log.ReadOnly = true;
            _log.BorderStyle = BorderStyle.None;
            _log.WordWrap = true;
            _log.DetectUrls = false;
            _log.HideSelection = false;
            Panel logWrap = new Panel();
            logWrap.Dock = DockStyle.Fill;
            logWrap.Tag = "input";
            logWrap.Padding = new Padding(14, 8, 8, 12);
            logWrap.Controls.Add(_log);

            Panel logBar = new Panel();
            logBar.Dock = DockStyle.Top;
            logBar.Height = 42;
            logBar.Tag = "panel";
            _lblOp = new Label();
            _lblOp.Dock = DockStyle.Fill;
            _lblOp.TextAlign = ContentAlignment.MiddleLeft;
            _lblOp.Padding = new Padding(14, 0, 0, 0);
            _lblOp.Font = new Font("Segoe UI Semibold", 9.5f);
            _lblOp.Text = "Ready";
            FlowLayoutPanel lb = new FlowLayoutPanel();
            lb.Dock = DockStyle.Right;
            lb.AutoSize = true;
            lb.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            lb.WrapContents = false;
            lb.Tag = "panel";
            lb.Padding = new Padding(0, 7, 10, 0);
            _btnStop = Btn("Stop", "danger", (s, e) => OnStop());
            _btnStop.Enabled = false;
            Button bClear = Btn("Clear", null, (s, e) => { _log.Clear(); _progStart = -1; });
            Button bCopy = Btn("Copy", null, (s, e) => CopyLog());
            foreach (Button x in new Button[] { _btnStop, bClear, bCopy })
            {
                x.MinimumSize = new Size(74, 28);
                x.Margin = new Padding(6, 0, 0, 0);
                lb.Controls.Add(x);
            }
            logBar.Controls.Add(_lblOp);
            logBar.Controls.Add(lb);

            _bar = new ProgressBar();
            _bar.Dock = DockStyle.Top;
            _bar.Height = 3;
            _bar.Style = ProgressBarStyle.Marquee;
            _bar.MarqueeAnimationSpeed = 30;
            _bar.Visible = false;

            Panel logPanel = new Panel();
            logPanel.Dock = DockStyle.Fill;
            logPanel.Controls.Add(logWrap);
            logPanel.Controls.Add(logBar);
            logPanel.Controls.Add(_bar);

            Panel content = new Panel();
            content.Dock = DockStyle.Fill;
            content.Controls.Add(logPanel);
            content.Controls.Add(_pageHost);

            Controls.Add(content);
            Controls.Add(nav);
            Controls.Add(hdr);

            _tick = new System.Windows.Forms.Timer();
            _tick.Interval = 500;
            _tick.Tick += (s, e) => UpdateElapsed();
        }

        Label StatusLabel()
        {
            Label l = new Label();
            l.AutoSize = true;
            l.Margin = new Padding(0, 6, 18, 0);
            l.Font = new Font("Segoe UI Semibold", 9.5f);
            return l;
        }

        Panel NewPage()
        {
            Panel p = new Panel();
            p.Dock = DockStyle.Fill;
            p.AutoScroll = true;
            p.Padding = new Padding(18, 14, 18, 8);
            p.Visible = false;
            return p;
        }

        TableLayoutPanel NewTable()
        {
            TableLayoutPanel t = new TableLayoutPanel();
            t.AutoSize = true;
            t.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            t.ColumnCount = 3;
            t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            t.RowCount = 0;
            return t;
        }

        FlowLayoutPanel NewFlow()
        {
            FlowLayoutPanel f = new FlowLayoutPanel();
            f.AutoSize = true;
            f.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            f.WrapContents = true;
            f.FlowDirection = FlowDirection.LeftToRight;
            f.Padding = new Padding(0, 4, 0, 0);
            return f;
        }

        // Stacks controls top to bottom in the order given (docked controls are laid out last-added first).
        void Stack(Panel page, params Control[] items)
        {
            for (int i = items.Length - 1; i >= 0; i--)
            {
                items[i].Dock = DockStyle.Top;
                page.Controls.Add(items[i]);
            }
        }

        Label Cap(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.Tag = "muted";
            l.AutoSize = true;
            l.Padding = new Padding(0, 12, 0, 4);
            l.Font = new Font("Segoe UI Semibold", 9f);
            return l;
        }

        Label Heading(string text)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Font = new Font("Segoe UI Semibold", 12.5f);
            l.Padding = new Padding(0, 0, 0, 6);
            return l;
        }

        Label Note(string text, int height)
        {
            Label l = new Label();
            l.Text = text;
            l.Tag = "muted";
            l.AutoSize = false;
            l.Height = height;
            l.Padding = new Padding(0, 6, 0, 0);
            return l;
        }

        // role: null = plain, "write" = accent border (writes to the device), "danger" = red border (erases data / flashes firmware)
        Button Btn(string text, string role, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.Tag = role;
            b.AutoSize = true;
            b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            b.MinimumSize = new Size(150, 34);
            b.Padding = new Padding(10, 0, 10, 0);
            b.Margin = new Padding(0, 0, 8, 8);
            b.FlatStyle = FlatStyle.Flat;
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.Click += click;
            return b;
        }

        TextBox Row(TableLayoutPanel table, string label, string filter, bool folder)
        {
            int r = table.RowCount;
            table.RowCount = r + 1;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label l = new Label();
            l.Text = label;
            l.AutoSize = true;
            l.Anchor = AnchorStyles.Left;
            l.Margin = new Padding(0, 6, 14, 6);
            TextBox tb = new TextBox();
            tb.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            tb.Margin = new Padding(0, 4, 0, 4);
            tb.AllowDrop = true;
            TextBox box = tb;
            tb.DragEnter += (s, e) =>
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
            };
            tb.DragDrop += (s, e) =>
            {
                string[] dropped = e.Data.GetData(DataFormats.FileDrop) as string[];
                if (dropped != null && dropped.Length > 0) box.Text = dropped[0];
            };
            table.Controls.Add(l, 0, r);
            table.Controls.Add(tb, 1, r);
            if (filter != null || folder)
            {
                string flt = filter;
                bool fol = folder;
                Button b = new Button();
                b.Text = "Browse...";
                b.AutoSize = true;
                b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                b.MinimumSize = new Size(90, 28);
                b.Anchor = AnchorStyles.Left;
                b.Margin = new Padding(8, 2, 0, 2);
                b.FlatStyle = FlatStyle.Flat;
                b.Cursor = Cursors.Hand;
                b.UseVisualStyleBackColor = false;
                b.Click += (s, e) => Browse(box, flt, fol);
                table.Controls.Add(b, 2, r);
            }
            return tb;
        }

        void RowCtl(TableLayoutPanel table, string label, Control c)
        {
            int r = table.RowCount;
            table.RowCount = r + 1;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Label l = new Label();
            l.Text = label;
            l.AutoSize = true;
            l.Anchor = AnchorStyles.Left;
            l.Margin = new Padding(0, 6, 14, 6);
            c.Anchor = AnchorStyles.Left;
            c.Margin = new Padding(0, 4, 0, 4);
            table.Controls.Add(l, 0, r);
            table.Controls.Add(c, 1, r);
        }

        void Browse(TextBox tb, string filter, bool folder)
        {
            string cur = tb.Text.Trim();
            if (folder)
            {
                using (FolderBrowserDialog d = new FolderBrowserDialog())
                {
                    d.Description = "Select folder";
                    if (cur.Length > 0 && Directory.Exists(cur)) d.SelectedPath = cur;
                    if (d.ShowDialog(this) == DialogResult.OK) tb.Text = d.SelectedPath;
                }
            }
            else
            {
                using (OpenFileDialog d = new OpenFileDialog())
                {
                    d.Filter = filter;
                    try
                    {
                        string dir = cur.Length > 0 ? Path.GetDirectoryName(cur) : null;
                        if (dir != null && Directory.Exists(dir)) d.InitialDirectory = dir;
                    }
                    catch (Exception) { }
                    if (d.ShowDialog(this) == DialogResult.OK) tb.Text = d.FileName;
                }
            }
        }

        // ---------------------------------------------------------------- pages

        Panel BuildMtk()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();
            _tbDA = Row(t, "DA file (DA_BR.bin)", "DA file (*.bin)|*.bin|All files|*.*", false);
            _tbAuth = Row(t, "Auth file (optional)", "Auth file (*.auth)|*.auth|All files|*.*", false);
            _tbPart = Row(t, "Partition name", null, false);
            _tbBackup = Row(t, "Backup folder", null, true);
            _tbImg = Row(t, "Image to write", "Image (*.img;*.bin)|*.img;*.bin|All files|*.*", false);
            _tbScatter = Row(t, "Scatter file (.xml)", "Scatter (*.xml)|*.xml|All files|*.*", false);
            _tbPreloader = Row(t, "Preloader (.bin)", "Preloader (*.bin)|*.bin|All files|*.*", false);

            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Check partitions", null, (s, e) => OpPgpt()));
            f.Controls.Add(Btn("Read all partitions", null, (s, e) => OpReadAll()));
            f.Controls.Add(Btn("Read partition", null, (s, e) => OpRead()));
            f.Controls.Add(Btn("Write partition", "danger", (s, e) => OpWrite()));
            f.Controls.Add(Btn("Firmware upgrade", "danger", (s, e) => OpScatter()));
            f.Controls.Add(Btn("Erase partition", "danger", (s, e) => OpErase()));
            f.Controls.Add(Btn("Reboot", null, (s, e) => OpReboot()));
            Stack(p, t, Cap("Operations"), f,
                Note("Each operation uses only the fields it needs. Accent border: writes to the device. Red border: erases data or flashes firmware. You can drop files onto the fields.", 44));
            return p;
        }

        Panel BuildFb()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();
            _tbVbmeta = Row(t, "vbmeta.img (stock)", ImgFilter, false);
            _tbEmpty = Row(t, "empty_partition.img", ImgFilter, false);
            _tbGsi = Row(t, "GSI system image", ImgFilter, false);
            _tbBoot = Row(t, "Root (patched boot) image", ImgFilter, false);
            _cbMethod = new ComboBox();
            _cbMethod.DropDownStyle = ComboBoxStyle.DropDownList;
            _cbMethod.FlatStyle = FlatStyle.Flat;
            _cbMethod.Width = 220;
            _cbMethod.Items.Add("ADB (recommended)");
            _cbMethod.Items.Add("Fastboot");
            _cbMethod.SelectedIndex = 0;
            RowCtl(t, "Reboot to bootloader via", _cbMethod);

            FlowLayoutPanel f1 = NewFlow();
            f1.Controls.Add(Btn("Detect devices", null, (s, e) => OpDetect()));
            f1.Controls.Add(Btn("Reboot to bootloader", null, (s, e) => OpRebootBl()));
            f1.Controls.Add(Btn("Unlock bootloader", "danger", (s, e) => OpLock(true)));
            f1.Controls.Add(Btn("Relock bootloader", "danger", (s, e) => OpLock(false)));
            FlowLayoutPanel f2 = NewFlow();
            f2.Controls.Add(Btn("Install GSI", "danger", (s, e) => OpGsi()));
            f2.Controls.Add(Btn("Install root image", "write", (s, e) => OpRoot()));
            f2.Controls.Add(Btn("Disable verity", "write", (s, e) => OpVerity()));
            f2.Controls.Add(Btn("Automated root", "write", (s, e) => OpAutoRoot()));
            FlowLayoutPanel f3 = NewFlow();
            f3.Controls.Add(Btn("Set slot A", "write", (s, e) => OpSlot("a")));
            f3.Controls.Add(Btn("Set slot B", "write", (s, e) => OpSlot("b")));
            f3.Controls.Add(Btn("Check slot", null, (s, e) => OpSlotCheck()));
            f3.Controls.Add(Btn("Reboot device", null, (s, e) => OpFbReboot()));
            Stack(p, t, Cap("Device and bootloader"), f1, Cap("Flash"), f2, Cap("Active slot (A / B)"), f3);
            return p;
        }

        Panel BuildDeb()
        {
            Panel p = NewPage();
            _lblDeb = new Label();
            _lblDeb.AutoSize = true;
            _lblDeb.Padding = new Padding(0, 4, 0, 8);
            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Scan phone", null, (s, e) => OpScan()));
            f.Controls.Add(Btn("Safe remove", "write", (s, e) => OpDebloat("SAFE")));
            f.Controls.Add(Btn("All-in-one remove", "danger", (s, e) => OpDebloat("ALL")));
            f.Controls.Add(Btn("Restore", null, (s, e) => OpDebloat("RESTORE")));
            Stack(p, Heading("Transsion debloat (ADB)"),
                Note("Enable Developer options and USB debugging on the phone first, then tap Allow when the phone asks. Removal keeps app data, and Restore brings the listed apps back.", 48),
                _lblDeb, f,
                Note("Safe remove skips apps that features depend on. All-in-one remove also removes the keyboard, file manager, browser, Phone Master / Manager, cloud, weather, Google app and Photos.", 48));
            SetDebCounts(null);
            return p;
        }

        Panel BuildLogs()
        {
            Panel p = NewPage();
            _lblFolder = new Label();
            _lblFolder.AutoSize = true;
            _lblFolder.Tag = "accent";
            _lblFolder.Padding = new Padding(0, 6, 0, 10);
            ShowLogFolder();
            _chkAsk = new CheckBox();
            _chkAsk.Text = "Ask for a folder after every operation";
            _chkAsk.AutoSize = true;
            _chkAsk.Checked = _askLog;
            _chkAsk.Padding = new Padding(0, 8, 0, 0);
            _chkAsk.CheckedChanged += (s, e) =>
            {
                if (_loading) return;
                _askLog = _chkAsk.Checked;
                SaveSettings();
            };
            FlowLayoutPanel f = NewFlow();
            f.Controls.Add(Btn("Change folder", null, (s, e) => ChangeLogFolder()));
            f.Controls.Add(Btn("Open folder", null, (s, e) => OpenLogFolder()));
            f.Controls.Add(Btn("Reset to default", null, (s, e) => ResetLogFolder()));
            f.Controls.Add(Btn("Open last log", null, (s, e) => OpenLastLog()));
            Stack(p, Heading("Logs and screenshots"),
                Note("After every flashing operation the tool saves two screenshots of this window and the whole output as a text log.", 44),
                _lblFolder, f, _chkAsk);
            return p;
        }

        Panel BuildAppearance()
        {
            Panel p = NewPage();
            TableLayoutPanel t = NewTable();

            _cbTheme = new ComboBox();
            _cbTheme.DropDownStyle = ComboBoxStyle.DropDownList;
            _cbTheme.FlatStyle = FlatStyle.Flat;
            _cbTheme.Width = 240;
            foreach (Theme th in _themes) _cbTheme.Items.Add(th.Name);
            _cbTheme.Items.Add("Custom");
            _cbTheme.SelectedIndex = (_themeIdx >= 0 && _themeIdx <= _themes.Count) ? _themeIdx : 0;
            _cbTheme.SelectedIndexChanged += (s, e) =>
            {
                if (_loading) return;
                _themeIdx = _cbTheme.SelectedIndex;
                ApplyTheme();
                SaveSettings();
            };
            RowCtl(t, "Theme", _cbTheme);

            FlowLayoutPanel cf = NewFlow();
            cf.Padding = new Padding(0);
            string[] cn = new string[] { "Background...", "Text...", "Accent..." };
            for (int i = 0; i < cn.Length; i++)
            {
                int which = i;
                Button cb = Btn(cn[i], null, (s, e) => PickCustom(which));
                cb.MinimumSize = new Size(110, 28);
                _custBtns.Add(cb);
                cf.Controls.Add(cb);
            }
            RowCtl(t, "Custom colors", cf);

            _cbFont = new ComboBox();
            _cbFont.DropDownStyle = ComboBoxStyle.DropDown;
            _cbFont.FlatStyle = FlatStyle.Flat;
            _cbFont.Width = 240;
            string[] pref = new string[] { "Consolas", "Cascadia Mono", "Cascadia Code", "Lucida Console", "Courier New", "Segoe UI" };
            HashSet<string> have = new HashSet<string>();
            foreach (FontFamily ff in FontFamily.Families) have.Add(ff.Name);
            foreach (string fn in pref)
            {
                if (have.Contains(fn)) _cbFont.Items.Add(fn);
            }
            _cbFont.Text = _logFont;
            _cbFont.SelectedIndexChanged += (s, e) => ChangeLogFont();
            _cbFont.Leave += (s, e) => ChangeLogFont();
            RowCtl(t, "Output font", _cbFont);

            _numSize = new NumericUpDown();
            _numSize.Minimum = 8;
            _numSize.Maximum = 28;
            _numSize.Width = 70;
            _numSize.Value = (decimal)Math.Max(8.0, Math.Min(28.0, Math.Round((double)_logSize)));
            _numSize.ValueChanged += (s, e) => ChangeLogFont();
            RowCtl(t, "Output font size", _numSize);

            Stack(p, Heading("Appearance"), t,
                Note("The theme and the font apply to this window and to the output area.", 36));
            return p;
        }

        void ChangeLogFont()
        {
            if (_loading) return;
            string n = _cbFont.Text.Trim();
            if (n.Length > 0) _logFont = n;
            _logSize = (float)_numSize.Value;
            ApplyLogFont();
            SaveSettings();
        }

        void PickCustom(int which)
        {
            using (ColorDialog d = new ColorDialog())
            {
                d.FullOpen = true;
                d.Color = which == 0 ? _custBg : (which == 1 ? _custFg : _custAcc);
                if (d.ShowDialog(this) != DialogResult.OK) return;
                if (which == 0) _custBg = d.Color;
                else if (which == 1) _custFg = d.Color;
                else _custAcc = d.Color;
            }
            if (_themeIdx >= _themes.Count) ApplyTheme();
            SaveSettings();
        }

        // ---------------------------------------------------------------- theme painting

        void ApplyTheme()
        {
            _t = CurrentTheme();
            bool light = Lum(_t.Bg) > 0.55;
            _green = Theme.H(light ? "1E8E3E" : "3DDC84");
            _red = Theme.H(light ? "C5221F" : "FF5A5F");
            _yel = Theme.H(light ? "9A5B00" : "F5C84C");
            BackColor = _t.Bg;
            ForeColor = _t.Fg;
            PaintTree(this);
            _log.BackColor = _t.Input;
            _log.ForeColor = _t.Fg;
            ApplyLogFont();
            if (_log.TextLength > 0)
            {
                _log.SelectAll();
                _log.SelectionColor = _t.Fg;
                _log.SelectionStart = _log.TextLength;
                _log.SelectionLength = 0;
            }
            foreach (Button cb in _custBtns) cb.Enabled = (_themeIdx >= _themes.Count);
            UpdateNav();
            UpdateToolStatus();
        }

        void PaintTree(Control c)
        {
            string role = c.Tag as string;
            if (c is Button)
            {
                Button b = (Button)c;
                b.FlatStyle = FlatStyle.Flat;
                b.UseVisualStyleBackColor = false;
                if (role == "nav")
                {
                    b.FlatAppearance.BorderSize = 0;
                    b.BackColor = _t.Panel;
                    b.ForeColor = _t.Fg;
                }
                else
                {
                    Color edge = role == "danger" ? _red : (role == "write" ? _t.Accent : _t.Muted);
                    b.FlatAppearance.BorderSize = 1;
                    b.FlatAppearance.BorderColor = edge;
                    b.BackColor = _t.Panel;
                    b.ForeColor = role == "danger" ? _red : (role == "write" ? _t.Accent : _t.Fg);
                }
                b.FlatAppearance.MouseOverBackColor = Blend(_t.Panel, _t.Fg, 0.12);
                b.FlatAppearance.MouseDownBackColor = Blend(_t.Panel, _t.Fg, 0.22);
            }
            else if (c is TextBox || c is ComboBox || c is NumericUpDown || c is RichTextBox)
            {
                c.BackColor = _t.Input;
                c.ForeColor = _t.Fg;
            }
            else if (c is Label)
            {
                c.ForeColor = role == "muted" ? _t.Muted : (role == "accent" ? _t.Accent : _t.Fg);
                c.BackColor = Color.Transparent;
            }
            else if (c is CheckBox)
            {
                c.ForeColor = _t.Fg;
                c.BackColor = Color.Transparent;
            }
            else if (c is ProgressBar)
            {
                // keep the system look
            }
            else
            {
                if (role == "panel") c.BackColor = _t.Panel;
                else if (role == "input") c.BackColor = _t.Input;
                else c.BackColor = _t.Bg;
                c.ForeColor = _t.Fg;
            }
            foreach (Control k in c.Controls) PaintTree(k);
        }

        void ApplyLogFont()
        {
            try { _log.Font = new Font(_logFont, _logSize); }
            catch (Exception) { _log.Font = new Font(FontFamily.GenericMonospace, _logSize); }
        }

        void UpdateNav()
        {
            for (int i = 0; i < _navBtns.Length; i++)
            {
                bool on = (i == _page);
                _navBtns[i].BackColor = on ? Blend(_t.Panel, _t.Accent, 0.16) : _t.Panel;
                _navBtns[i].ForeColor = on ? _t.Accent : _t.Fg;
                _navBtns[i].FlatAppearance.MouseOverBackColor = Blend(_t.Panel, _t.Fg, 0.1);
            }
        }

        void ShowPage(int i)
        {
            _page = i;
            for (int k = 0; k < _pages.Length; k++) _pages[k].Visible = (k == i);
            if (_t != null) UpdateNav();
        }

        void UpdateToolStatus()
        {
            SetSt(_stT, "antumbra", FindTool("antumbra.exe") != null);
            SetSt(_stA, "adb", FindTool("adb.exe") != null);
            SetSt(_stF, "fastboot", FindTool("fastboot.exe") != null);
        }

        void SetSt(Label l, string name, bool ok)
        {
            l.Text = (ok ? "\u25CF " : "\u25CB ") + name;
            l.ForeColor = ok ? _green : _red;
        }

        void Welcome()
        {
            SayC("Flash Tool v" + Version + "  by Thomus Shelby", _t.Accent);
            Say("Working folder: " + _appDir);
            ToolLine("antumbra.exe");
            ToolLine("adb.exe");
            ToolLine("fastboot.exe");
            Say("");
        }

        void ToolLine(string name)
        {
            string p = FindTool(name);
            if (p == null) SayC("  " + name + " : not found - put it next to this app or add it to PATH", _red);
            else Say("  " + name + " : " + p);
        }

        // ---------------------------------------------------------------- output log

        // mode 0 = normal line, 1 = progress line (replaced by the next write), 2 = finish the current progress line
        void UiLog(string s, Color c, int mode)
        {
            if (InvokeRequired)
            {
                try { BeginInvoke(new MethodInvoker(delegate { UiLog(s, c, mode); })); }
                catch (Exception) { }
                return;
            }
            if (_progStart >= 0)
            {
                if (mode == 2)
                {
                    _log.AppendText("\n");
                    _progStart = -1;
                    ScrollEnd();
                    return;
                }
                _log.Select(_progStart, _log.TextLength - _progStart);
                _log.SelectedText = "";
                _progStart = -1;
            }
            if (mode == 2) return;
            if (_log.TextLength > 400000)
            {
                _log.Select(0, 100000);
                _log.SelectedText = "";
            }
            int start = _log.TextLength;
            _log.SelectionStart = start;
            _log.SelectionLength = 0;
            _log.SelectionColor = c;
            _log.AppendText(mode == 0 ? s + "\n" : s);
            if (mode == 1) _progStart = start;
            ScrollEnd();
        }

        void ScrollEnd()
        {
            _log.SelectionStart = _log.TextLength;
            _log.SelectionLength = 0;
            _log.ScrollToCaret();
        }

        void Say(string s) { UiLog(s, _t.Fg, 0); }

        void SayC(string s, Color c) { UiLog(s, c, 0); }

        void UiSet(Control c, string text)
        {
            if (InvokeRequired)
            {
                try { BeginInvoke(new MethodInvoker(delegate { c.Text = text; })); }
                catch (Exception) { }
                return;
            }
            c.Text = text;
        }

        // ---------------------------------------------------------------- running tools

        void EmitProc(string text, bool progress)
        {
            text = Ansi.Replace(text, "");
            if (progress && text.Trim().Length == 0) return;
            Color c = _t.Fg;
            if (text.IndexOf("FAILED", StringComparison.Ordinal) >= 0 || text.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0) c = _red;
            else if (text.IndexOf("OKAY", StringComparison.Ordinal) >= 0) c = _green;
            UiLog("  " + text, c, progress ? 1 : 0);
        }

        // Reads a tool's output live. A lone carriage return means a progress line that the next write replaces.
        void PumpLive(StreamReader r)
        {
            StringBuilder line = new StringBuilder();
            bool cr = false;
            int ch;
            while ((ch = r.Read()) != -1)
            {
                char c = (char)ch;
                if (c == '\r')
                {
                    if (line.Length > 0)
                    {
                        EmitProc(line.ToString(), true);
                        line.Length = 0;
                    }
                    cr = true;
                }
                else if (c == '\n')
                {
                    if (line.Length > 0) EmitProc(line.ToString(), false);
                    else if (cr) UiLog("", _t.Fg, 2);
                    else EmitProc("", false);
                    line.Length = 0;
                    cr = false;
                }
                else
                {
                    line.Append(c);
                    cr = false;
                }
            }
            if (line.Length > 0) EmitProc(line.ToString(), false);
        }

        void Pump(StreamReader r, bool live, StringBuilder cap)
        {
            try
            {
                if (live)
                {
                    PumpLive(r);
                }
                else
                {
                    string s = r.ReadToEnd();
                    lock (cap)
                    {
                        cap.Append(s);
                        cap.Append('\n');
                    }
                }
            }
            catch (Exception) { }
        }

        int RunProc(string tool, string args, bool live, StringBuilder cap, int timeoutMs)
        {
            string path = FindTool(tool);
            if (path == null)
            {
                if (live) SayC("  " + tool + " not found.", _red);
                return 9009;
            }
            ProcessStartInfo psi = new ProcessStartInfo(path, args);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            psi.WorkingDirectory = _appDir;
            psi.EnvironmentVariables["NO_COLOR"] = "1";
            Process p = new Process();
            p.StartInfo = psi;
            try
            {
                p.Start();
            }
            catch (Exception ex)
            {
                SayC("  Could not start " + tool + ": " + ex.Message, _red);
                return 9009;
            }
            if (live) _proc = p;
            Thread tOut = new Thread(() => Pump(p.StandardOutput, live, cap));
            Thread tErr = new Thread(() => Pump(p.StandardError, live, cap));
            tOut.IsBackground = true;
            tErr.IsBackground = true;
            tOut.Start();
            tErr.Start();
            int code;
            if (timeoutMs > 0 && !p.WaitForExit(timeoutMs))
            {
                try { p.Kill(); } catch (Exception) { }
                code = -1;
            }
            else
            {
                p.WaitForExit();
                code = p.ExitCode;
            }
            tOut.Join(3000);
            tErr.Join(3000);
            if (live) _proc = null;
            try { p.Dispose(); } catch (Exception) { }
            return code;
        }

        // runs a tool and shows its output in the log
        int Exec(string tool, string args)
        {
            SayC("> " + Path.GetFileNameWithoutExtension(tool) + " " + args, _t.Accent);
            return RunProc(tool, args, true, null, 0);
        }

        // runs a tool quietly and returns its output
        string Grab(string tool, string args)
        {
            StringBuilder sb = new StringBuilder();
            RunProc(tool, args, false, sb, 30000);
            return sb.ToString();
        }

        string FindTool(string name)
        {
            string n = name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? name : name + ".exe";
            try
            {
                string local = Path.Combine(_appDir, n);
                if (File.Exists(local)) return local;
            }
            catch (Exception) { }
            string pathVar = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (string d in pathVar.Split(';'))
            {
                try
                {
                    string dir = d.Trim().Trim('"');
                    if (dir.Length == 0) continue;
                    string full = Path.Combine(dir, n);
                    if (File.Exists(full)) return full;
                }
                catch (Exception) { }
            }
            return null;
        }

        void KillProc()
        {
            Process p = _proc;
            if (p == null) return;
            try
            {
                ProcessStartInfo k = new ProcessStartInfo("taskkill", "/PID " + p.Id + " /T /F");
                k.CreateNoWindow = true;
                k.UseShellExecute = false;
                Process kp = Process.Start(k);
                if (kp != null) kp.WaitForExit(3000);
            }
            catch (Exception) { }
            try { if (!p.HasExited) p.Kill(); } catch (Exception) { }
        }

        // quotes one command line argument
        static string Q(string s)
        {
            if (s == null) s = "";
            int trailing = 0;
            for (int i = s.Length - 1; i >= 0 && s[i] == '\\'; i--) trailing++;
            return "\"" + s.Replace("\"", "\\\"") + new string('\\', trailing) + "\"";
        }

        // ---------------------------------------------------------------- jobs

        void StartJob(string name, Func<int> body, bool save)
        {
            if (_busy) return;
            if (save && _askLog) AskFolderNow();
            _opName = name;
            _opDesc = "";
            _opRes = 0;
            _cancel = false;
            _opSave = save;
            _opStart = DateTime.Now;
            _sw = Stopwatch.StartNew();
            _lblOp.ForeColor = _t.Fg;
            SetBusy(true);
            Thread th = new Thread(() =>
            {
                int rc = 1;
                try
                {
                    rc = body();
                }
                catch (Exception ex)
                {
                    SayC("  Error: " + ex.Message, _red);
                    rc = 1;
                }
                _opRes = rc;
                try { BeginInvoke(new MethodInvoker(FinishJob)); }
                catch (Exception) { }
            });
            th.IsBackground = true;
            th.Start();
        }

        void SetBusy(bool b)
        {
            _busy = b;
            _pageHost.Enabled = !b;
            _btnStop.Enabled = b;
            _bar.Visible = b;
            if (b)
            {
                _tick.Start();
                _lblOp.Text = "Running: " + _opName;
            }
            else
            {
                _tick.Stop();
                _lblOp.Text = "Ready";
            }
        }

        static string Fmt(TimeSpan ts)
        {
            return string.Format("{0:00}:{1:00}:{2:00}", (int)ts.TotalHours, ts.Minutes, ts.Seconds);
        }

        void UpdateElapsed()
        {
            if (_busy && _sw != null) _lblOp.Text = "Running: " + _opName + "   " + Fmt(_sw.Elapsed);
        }

        int Done(int rc, string desc)
        {
            _opDesc = desc;
            return rc;
        }

        int StepFail(string what, string step)
        {
            _opDesc = what + " FAILED at step: " + step;
            SayC("  Step failed: " + step + " - stopped, remaining steps were NOT run.", _red);
            return 1;
        }

        // waits in small steps so Stop works; false = stopped
        bool Sleep(int seconds)
        {
            for (int i = 0; i < seconds * 10; i++)
            {
                if (_cancel) return false;
                Thread.Sleep(100);
            }
            return !_cancel;
        }

        // asks a question from a worker thread
        bool AskYesNo(string msg)
        {
            bool yes = false;
            Invoke(new MethodInvoker(delegate
            {
                yes = MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
            }));
            return yes;
        }

        void FinishJob()
        {
            if (_sw != null) _sw.Stop();
            TimeSpan ts = _sw != null ? _sw.Elapsed : TimeSpan.Zero;
            string dur = string.Format("{0}h {1}m {2}.{3:00}s", (int)ts.TotalHours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
            DateTime end = DateTime.Now;
            bool ok = (_opRes == 0 && !_cancel);
            string resTxt = _cancel ? "STOPPED by user" : (ok ? "SUCCESS" : "FAILED - exit code " + _opRes);
            if (_cancel && _opDesc.Length == 0) _opDesc = "Stopped by user";
            SetBusy(false);
            _lblOp.Text = _opName + ":  " + resTxt + "   (" + dur + ")";
            _lblOp.ForeColor = ok ? _green : _red;
            UpdateToolStatus();
            if (!_opSave) return;

            string dir = _logFolder;
            string safe = Regex.Replace(_opName, "[^A-Za-z0-9]+", "_").Trim('_');
            if (safe.Length == 0) safe = "operation";
            string stamp = end.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + "_" + safe;
            string f1 = Path.Combine(dir, stamp + "_1_flashing_done.png");
            string f2 = Path.Combine(dir, stamp + "_2_flashing_time.png");
            string ft = Path.Combine(dir, stamp + "_screen_log.txt");
            string err = "";
            try
            {
                Directory.CreateDirectory(dir);
                Shot(f1);
            }
            catch (Exception ex) { err = ex.Message; }

            string rule = new string('=', 76);
            Say("");
            Say(rule);
            SayC("  FLASH TOOL  -  OPERATION SUMMARY", _t.Accent);
            Say(rule);
            Say("");
            Say("  Operation   : " + _opName);
            Say("  Started     : " + _opStart.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            Say("  Finished    : " + end.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            SayC("  Flash time  : " + dur, _yel);
            SayC("  Result      : " + resTxt, ok ? _green : _red);
            if (_opDesc.Length > 0) Say("  Details     : " + _opDesc);
            Say("");
            Say("  Saved in    : " + dir);
            if (err.Length > 0)
            {
                SayC("  Capture problem: " + err, _red);
            }
            else
            {
                Say("  Files       : " + Path.GetFileName(f1));
                Say("                " + Path.GetFileName(f2));
                Say("                " + Path.GetFileName(ft));
            }
            Say(rule);

            try
            {
                File.WriteAllText(ft, _log.Text.Replace("\r\n", "\n").Replace("\n", "\r\n") + "\r\n", new UTF8Encoding(false));
                Shot(f2);
            }
            catch (Exception ex2) { SayC("  Capture problem: " + ex2.Message, _red); }
        }

        // saves a picture of this window
        void Shot(string path)
        {
            Application.DoEvents();
            Rectangle r = Bounds;
            using (Bitmap bmp = new Bitmap(r.Width, r.Height))
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    DrawToBitmap(bmp, new Rectangle(0, 0, r.Width, r.Height));
                }
                else
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.CopyFromScreen(r.Location, Point.Empty, r.Size);
                    }
                }
                bmp.Save(path, ImageFormat.Png);
            }
        }

        void OnStop()
        {
            if (!_busy) return;
            if (!Confirm("Stop the running operation?\n\nStopping in the middle of a write can leave the device in a bad state.")) return;
            _cancel = true;
            KillProc();
            SayC("  Stopped by user.", _yel);
        }

        void CopyLog()
        {
            try
            {
                if (_log.TextLength > 0) Clipboard.SetText(_log.Text);
            }
            catch (Exception ex) { Warn(ex.Message); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_busy)
            {
                DialogResult r = MessageBox.Show(this, "An operation is still running. Stop it and exit?", "Flash Tool",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }
                _cancel = true;
                KillProc();
            }
            SaveSettings();
            base.OnFormClosing(e);
        }

        void AskFolderNow()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Where to save the log and screenshots of this operation";
                if (Directory.Exists(_logFolder)) d.SelectedPath = _logFolder;
                if (d.ShowDialog(this) == DialogResult.OK) _logFolder = d.SelectedPath;
            }
        }

        void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (Exception) { }
        }

        // ---------------------------------------------------------------- dialogs and input checks

        void Warn(string msg)
        {
            MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        void Info(string msg)
        {
            MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        bool Confirm(string msg)
        {
            return MessageBox.Show(this, msg, "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes;
        }

        bool NeedTool()
        {
            if (FindTool("antumbra.exe") != null) return true;
            Warn("antumbra.exe not found.\n\nPut this app in the same folder as antumbra.exe, or add it to PATH.");
            return false;
        }

        bool NeedFb()
        {
            if (FindTool("fastboot.exe") != null) return true;
            Warn("fastboot not found.\n\nInstall Android platform-tools and add it to PATH, or put this app in the platform-tools folder.");
            return false;
        }

        bool NeedAdb()
        {
            if (FindTool("adb.exe") != null) return true;
            Warn("adb not found.\n\nInstall Android platform-tools and add it to PATH, or put this app in the platform-tools folder.");
            return false;
        }

        bool NeedFile(TextBox tb, string what)
        {
            string p = tb.Text.Trim();
            if (p.Length == 0)
            {
                Warn("Select " + what + " first.");
                tb.Focus();
                return false;
            }
            if (!File.Exists(p))
            {
                Warn("File not found:\n" + p);
                tb.Focus();
                return false;
            }
            return true;
        }

        bool NeedDir(TextBox tb, string what)
        {
            string p = tb.Text.Trim();
            if (p.Length == 0)
            {
                Warn("Select " + what + " first.");
                tb.Focus();
                return false;
            }
            if (!Directory.Exists(p))
            {
                Warn("Folder not found:\n" + p);
                tb.Focus();
                return false;
            }
            return true;
        }

        bool NeedText(TextBox tb, string what)
        {
            if (tb.Text.Trim().Length > 0) return true;
            Warn("Type " + what + " first.");
            tb.Focus();
            return false;
        }

        // ---------------------------------------------------------------- adb / fastboot helpers (run on the worker thread)

        List<string> FbDevices()
        {
            List<string> r = new List<string>();
            foreach (string l in Grab("fastboot.exe", "devices").Split('\n'))
            {
                string t = l.Trim();
                if (t.Length > 0) r.Add(t);
            }
            return r;
        }

        // true = a fastboot device was found. Checks every 2 seconds, up to "tries" times.
        bool WaitFb(int tries)
        {
            int wt = 0;
            while (true)
            {
                if (_cancel) return false;
                if (FbDevices().Count > 0) return true;
                wt++;
                if (wt >= tries) return false;
                Say("  Waiting for the device... (" + wt + "/" + tries + ")");
                if (!Sleep(2)) return false;
            }
        }

        List<string> AdbLines()
        {
            List<string> r = new List<string>();
            foreach (string l in Grab("adb.exe", "devices").Split('\n'))
            {
                string t = l.Trim();
                if (t.Length == 0) continue;
                if (t.StartsWith("List", StringComparison.Ordinal)) continue;
                if (t.StartsWith("*", StringComparison.Ordinal)) continue;
                if (t.StartsWith("adb server", StringComparison.Ordinal)) continue;
                r.Add(t);
            }
            return r;
        }

        // device / unauthorized / offline, or "" when no adb device is connected
        string AdbState()
        {
            string st = "";
            foreach (string t in AdbLines())
            {
                string[] parts = t.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2) st = parts[1];
            }
            return st;
        }

        // waits until the phone has allowed USB debugging
        bool AdbAllow()
        {
            if (FindTool("adb.exe") == null)
            {
                SayC("  adb not found. Install Android platform-tools and add it to PATH.", _red);
                return false;
            }
            Say("");
            Exec("adb.exe", "devices");
            Say("");
            SayC("  Please allow USB debugging in your device - tap Allow on the phone screen.", _yel);
            int tr = 0;
            while (true)
            {
                string st = AdbState();
                if (st.Equals("device", StringComparison.OrdinalIgnoreCase))
                {
                    Say("  adb device authorized.");
                    return true;
                }
                tr++;
                if (st.Length == 0 && tr >= 4) break;
                if (tr >= 15) break;
                if (st.Length > 0) Say("  Device state: " + st + " - waiting for you to allow it...");
                if (!Sleep(2)) return false;
            }
            SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
            return false;
        }

        // reboots to the bootloader with the ADB or the Fastboot method and waits for it
        bool GoBootloader(bool viaAdb)
        {
            _bmName = viaAdb ? "ADB" : "Fastboot";
            if (viaAdb)
            {
                if (FindTool("adb.exe") == null)
                {
                    SayC("  adb not found. Install Android platform-tools or use the Fastboot method.", _red);
                    return false;
                }
                Say("");
                Exec("adb.exe", "devices");
                Say("");
                SayC("  Please allow USB debugging in your device - tap Allow on the phone screen.", _yel);
                int tr = 0;
                while (true)
                {
                    string st = AdbState();
                    if (st.Length == 0)
                    {
                        SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
                        return false;
                    }
                    if (st.Equals("device", StringComparison.OrdinalIgnoreCase)) break;
                    Say("  Device state: " + st + " - waiting for you to allow it...");
                    tr++;
                    if (tr >= 15)
                    {
                        SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
                        return false;
                    }
                    if (!Sleep(2)) return false;
                }
                Say("  adb device authorized.");
                if (Exec("adb.exe", "reboot bootloader") != 0) return false;
            }
            else
            {
                Say("");
                Exec("fastboot.exe", "devices");
                if (!WaitFb(1))
                {
                    SayC("  No fastboot device detected. Put the device in fastboot mode first.", _red);
                    return false;
                }
                if (Exec("fastboot.exe", "reboot bootloader") != 0) return false;
            }
            if (!Sleep(4)) return false;
            Say("");
            Say("  > fastboot devices  - waiting for the bootloader");
            if (!WaitFb(20))
            {
                SayC("  Bootloader not detected - stopped.", _red);
                return false;
            }
            Exec("fastboot.exe", "devices");
            Say("");
            SayC("  Bootloader detected - please wait 3-4 sec for the flashing commands...", _green);
            return Sleep(4);
        }

        // ---------------------------------------------------------------- MediaTek (antumbra)

        string AuthArg()
        {
            string a = _tbAuth.Text.Trim();
            return a.Length == 0 ? "" : " -a " + Q(a);
        }

        string DaArg()
        {
            return " -d " + Q(_tbDA.Text.Trim()) + AuthArg();
        }

        // antumbra present, DA file chosen, optional Auth file valid
        bool MtkReady()
        {
            if (!NeedTool()) return false;
            if (!NeedFile(_tbDA, "the DA file (DA_BR.bin)")) return false;
            string a = _tbAuth.Text.Trim();
            if (a.Length > 0 && !File.Exists(a))
            {
                Warn("Auth file not found:\n" + a + "\n\nClear the field to continue without it.");
                _tbAuth.Focus();
                return false;
            }
            return true;
        }

        void OpPgpt()
        {
            if (!MtkReady()) return;
            string cmd = "pgpt" + DaArg();
            StartJob("Check partitions", () => Done(Exec("antumbra.exe", cmd), "Check partitions"), true);
        }

        void OpReadAll()
        {
            if (!MtkReady() || !NeedDir(_tbBackup, "the backup folder")) return;
            string bk = _tbBackup.Text.Trim();
            string cmd = "read-all --skip userdata " + Q(bk) + DaArg();
            StartJob("Read all partitions", () => Done(Exec("antumbra.exe", cmd), "Read all partitions (backup to " + bk + ")"), true);
        }

        void OpRead()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to read") || !NeedDir(_tbBackup, "the backup folder")) return;
            string part = _tbPart.Text.Trim();
            string target = Path.Combine(_tbBackup.Text.Trim(), part + ".bin");
            string cmd = "read " + Q(part) + " " + Q(target) + DaArg();
            StartJob("Read partition " + part, () =>
            {
                Say("  READ partition: \"" + part + "\"");
                Say("  Save as: \"" + target + "\"");
                return Done(Exec("antumbra.exe", cmd), "Read partition " + part);
            }, true);
        }

        void OpWrite()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to write") || !NeedFile(_tbImg, "the image file to write")) return;
            string part = _tbPart.Text.Trim();
            string img = _tbImg.Text.Trim();
            if (!Confirm("WRITE file:\n" + img + "\n\nTO partition: \"" + part + "\"\n\nContinue?")) return;
            string cmd = "write " + Q(part) + " " + Q(img) + DaArg();
            StartJob("Write partition " + part, () => Done(Exec("antumbra.exe", cmd), "Write partition " + part), true);
        }

        void OpErase()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to erase")) return;
            string part = _tbPart.Text.Trim();
            if (!Confirm("ERASE partition: \"" + part + "\"\n\nThis cannot be undone. Continue?")) return;
            string cmd = "format " + Q(part) + DaArg();
            StartJob("Erase partition " + part, () => Done(Exec("antumbra.exe", cmd), "Erase partition " + part), true);
        }

        void OpReboot()
        {
            if (!MtkReady()) return;
            string cmd = "reboot" + DaArg();
            StartJob("Reboot", () => Done(Exec("antumbra.exe", cmd), "Reboot"), true);
        }

        void OpScatter()
        {
            if (!MtkReady()) return;
            if (!NeedFile(_tbScatter, "the scatter file (.xml)") || !NeedFile(_tbPreloader, "the preloader file (.bin)")) return;
            string scatter = _tbScatter.Text.Trim();
            string pre = _tbPreloader.Text.Trim();
            string da = DaArg();
            string opFile, opTemp;
            if (!OpSplit(scatter, out opFile, out opTemp)) return;
            bool opOnly = (opFile != null);
            string target = opOnly ? opFile : scatter;
            string question = opOnly
                ? "This will FLASH the OP part only - the base is skipped.\n\nScatter: " + target + "\n\nContinue?"
                : "This will FLASH the device.\n\nScatter: " + scatter + "\n\nContinue?";
            if (!Confirm(question))
            {
                if (opTemp != null) TryDelete(opTemp);
                return;
            }
            string tag = opOnly ? " - OP only" : "";
            string cmd = "scatter " + Q(target) + da + " -p " + Q(pre);
            StartJob("Firmware upgrade" + tag, () =>
            {
                int rc = Exec("antumbra.exe", cmd);
                if (opTemp != null) TryDelete(opTemp);
                return Done(rc, "Firmware upgrade" + tag);
            }, true);
        }

        // ---------------------------------------------------------------- OP firmware: flash the OP part only

        static bool IsOpName(string name)
        {
            return Regex.IsMatch("\"" + name + "\"", "open|[^a-zA-Z0-9]op[^a-zA-Z0-9]", RegexOptions.IgnoreCase);
        }

        // Looks for an OP folder (for example Open-Payjoy) inside the scatter folder.
        // false = cancelled. opFile = scatter to flash when "OP only" was chosen. opTemp = temporary scatter to delete afterwards.
        bool OpSplit(string scatter, out string opFile, out string opTemp)
        {
            opFile = null;
            opTemp = null;
            string sdir = Path.GetDirectoryName(scatter);
            if (sdir == null) return true;
            string opDir = null;
            try
            {
                foreach (string d in Directory.GetDirectories(sdir))
                {
                    if (IsOpName(Path.GetFileName(d)))
                    {
                        opDir = d;
                        break;
                    }
                }
            }
            catch (Exception) { }
            Say("");
            if (opDir == null)
            {
                string sname = Path.GetFileName(sdir);
                if (IsOpName(sname)) Say("  OP check : this scatter is inside the OP folder " + sname + " - that is the OP build.");
                else Say("  OP check : no Open / OP folder next to the scatter - normal firmware.");
                return true;
            }
            string opName = Path.GetFileName(opDir);
            int nFiles = 0;
            List<string> scatters = new List<string>();
            try
            {
                nFiles = Directory.GetFiles(opDir).Length;
                foreach (string f in Directory.GetFiles(opDir, "*scatter*.xml", SearchOption.AllDirectories))
                {
                    if (f.IndexOf("_oponly", StringComparison.OrdinalIgnoreCase) < 0) scatters.Add(f);
                }
            }
            catch (Exception) { }
            if (nFiles == 0 && scatters.Count == 0)
            {
                Say("  OP check : the folder " + opName + " has no files - ignored, normal firmware.");
                return true;
            }
            Say("  OP build detected - OP folder: " + opName + "  [" + nFiles + " files]");
            DialogResult dr = MessageBox.Show(this,
                "OP build detected - OP folder: " + opName + "  [" + nFiles + " files]\n\n" +
                "Yes = OP only (flash only the OP part, the base is skipped)\n" +
                "No = Base (normal firmware upgrade)\n" +
                "Cancel = do nothing",
                "OP firmware", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (dr == DialogResult.Cancel) return false;
            if (dr == DialogResult.No) return true;
            if (scatters.Count == 1)
            {
                opFile = scatters[0];
            }
            else if (scatters.Count > 1)
            {
                string pick = PickFromList("More than one scatter was found in the OP folder", scatters);
                if (pick == null) return false;
                opFile = pick;
            }
            else
            {
                // no scatter in the OP folder: build a copy of the base scatter that flashes only the images found in the OP folder
                string dst = Path.Combine(opDir, Path.GetFileNameWithoutExtension(scatter) + "_oponly" + Path.GetExtension(scatter));
                TryDelete(dst);
                if (!BuildOpOnly(scatter, opDir, dst))
                {
                    Say("");
                    Say("  Nothing was changed - the OP-only list could not be built.");
                    return false;
                }
                opFile = dst;
                opTemp = dst;
            }
            Say("  OP scatter : " + opFile);
            return true;
        }

        string PickFromList(string title, List<string> items)
        {
            using (Form f = new Form())
            {
                f.Text = title;
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(720, 280);
                f.BackColor = _t.Bg;
                f.ForeColor = _t.Fg;
                ListBox lb = new ListBox();
                lb.Dock = DockStyle.Fill;
                lb.BackColor = _t.Input;
                lb.ForeColor = _t.Fg;
                lb.BorderStyle = BorderStyle.None;
                foreach (string it in items) lb.Items.Add(it);
                lb.SelectedIndex = 0;
                Panel bar = new Panel();
                bar.Dock = DockStyle.Bottom;
                bar.Height = 46;
                Button ok = new Button();
                ok.Text = "Flash this scatter";
                ok.DialogResult = DialogResult.OK;
                ok.SetBounds(440, 9, 160, 28);
                Button cancel = new Button();
                cancel.Text = "Cancel";
                cancel.DialogResult = DialogResult.Cancel;
                cancel.SetBounds(610, 9, 96, 28);
                bar.Controls.Add(ok);
                bar.Controls.Add(cancel);
                f.Controls.Add(lb);
                f.Controls.Add(bar);
                f.AcceptButton = ok;
                f.CancelButton = cancel;
                if (f.ShowDialog(this) == DialogResult.OK && lb.SelectedIndex >= 0) return (string)lb.SelectedItem;
            }
            return null;
        }

        static string SetFile(string l, string v)
        {
            v = v.Replace("$", "$$");
            l = Regex.Replace(l, @"(file_name\s*:\s*)\S+", "${1}" + v, RegexOptions.IgnoreCase);
            l = Regex.Replace(l, @"(<file_name>\s*)[^<]*?(\s*</file_name>)", "${1}" + v + "${2}", RegexOptions.IgnoreCase);
            l = Regex.Replace(l, @"(file_name\s*=\s*"")[^""]*("")", "${1}" + v + "${2}", RegexOptions.IgnoreCase);
            return l;
        }

        static string SetOff(string l)
        {
            return Regex.Replace(l, @"(is_download(?:\s*[:=]\s*""?|>\s*))(true|1|yes)", "${1}false", RegexOptions.IgnoreCase);
        }

        // Writes a copy of the scatter that downloads only the images present in the OP folder.
        bool BuildOpOnly(string src, string opdir, string dst)
        {
            try
            {
                string text = File.ReadAllText(src);
                string nl = text.IndexOf("\r\n", StringComparison.Ordinal) >= 0 ? "\r\n" : "\n";
                string[] lines = Regex.Split(text, "\r?\n");
                Regex rxName = new Regex(@"partition_name(?:\s*[:=]\s*""?|>\s*)([^\s""<]+)", RegexOptions.IgnoreCase);
                Regex rxFile = new Regex(@"file_name(?:\s*[:=]\s*""?|>\s*)([^\s""<]+)", RegexOptions.IgnoreCase);
                Regex rxDl = new Regex(@"is_download(?:\s*[:=]\s*""?|>\s*)(true|false|1|0|yes|no)", RegexOptions.IgnoreCase);
                List<Part> parts = new List<Part>();
                Part cur = null;
                for (int i = 0; i < lines.Length; i++)
                {
                    Match m = rxName.Match(lines[i]);
                    if (m.Success)
                    {
                        cur = new Part();
                        cur.Name = m.Groups[1].Value;
                        parts.Add(cur);
                    }
                    if (cur == null) continue;
                    m = rxFile.Match(lines[i]);
                    if (m.Success && cur.FileLine < 0)
                    {
                        cur.Img = m.Groups[1].Value;
                        cur.FileLine = i;
                    }
                    m = rxDl.Match(lines[i]);
                    if (m.Success && cur.DlLine < 0)
                    {
                        cur.Dl = Regex.IsMatch(m.Groups[1].Value, "^(true|1|yes)$", RegexOptions.IgnoreCase);
                        cur.DlLine = i;
                    }
                }
                Dictionary<string, string> opfiles = new Dictionary<string, string>();
                foreach (string f in Directory.GetFiles(opdir))
                {
                    opfiles[Path.GetFileName(f).ToLowerInvariant()] = Path.GetFileName(f);
                }
                List<Part> keep = new List<Part>();
                List<Part> skip = new List<Part>();
                int actN = 0;
                foreach (Part p in parts)
                {
                    if (!(p.Dl && p.Img != "" && p.Img != "NONE")) continue;
                    actN++;
                    string key = Path.GetFileName(p.Img).ToLowerInvariant();
                    string real;
                    if (opfiles.TryGetValue(key, out real))
                    {
                        p.OpName = real;
                        keep.Add(p);
                    }
                    else
                    {
                        skip.Add(p);
                    }
                }
                if (actN < 3)
                {
                    Say("  Could not read the partition list from the scatter.");
                    return false;
                }
                if (keep.Count == 0)
                {
                    Say("  None of the " + actN + " images listed in the scatter were found in the OP folder.");
                    Say("  Files in the OP folder:");
                    int shown = 0;
                    foreach (string f2 in Directory.GetFiles(opdir))
                    {
                        if (shown++ >= 25) break;
                        Say("    " + Path.GetFileName(f2));
                    }
                    Say("  Images the scatter lists:");
                    shown = 0;
                    foreach (Part p2 in skip)
                    {
                        if (shown++ >= 25) break;
                        Say("    " + p2.Img);
                    }
                    return false;
                }
                List<string> outl = new List<string>(lines);
                foreach (Part p3 in keep)
                {
                    if (p3.FileLine >= 0) outl[p3.FileLine] = SetFile(outl[p3.FileLine], p3.OpName);
                }
                foreach (Part p4 in skip)
                {
                    if (p4.DlLine >= 0) outl[p4.DlLine] = SetOff(outl[p4.DlLine]);
                    if (p4.FileLine >= 0) outl[p4.FileLine] = SetFile(outl[p4.FileLine], "NONE");
                }
                File.WriteAllText(dst, string.Join(nl, outl.ToArray()), new UTF8Encoding(false));
                List<string> names = new List<string>();
                foreach (Part p5 in keep) names.Add(p5.Name);
                Say("  OP folder : " + opdir);
                Say("  Will flash " + keep.Count + " partitions from the OP folder:");
                Say("    " + string.Join(", ", names.ToArray()));
                Say("  Skipped    " + skip.Count + " base partitions");
                return true;
            }
            catch (Exception ex)
            {
                Say("  Error: " + ex.Message);
                return false;
            }
        }

        // ---------------------------------------------------------------- Fastboot / GSI

        void OpDetect()
        {
            if (!NeedFb()) return;
            StartJob("Device detection", () =>
            {
                string fb = "no";
                string ad = "skipped";
                Say("  > fastboot devices");
                foreach (string l in FbDevices())
                {
                    Say("  " + l);
                    fb = "yes";
                }
                Say(fb == "yes" ? "  -> Fastboot device DETECTED" : "  -> No fastboot device detected");
                Say("");
                if (FindTool("adb.exe") == null)
                {
                    Say("  adb not found - adb check skipped.");
                }
                else
                {
                    ad = "no";
                    Say("  > adb devices");
                    foreach (string l in AdbLines())
                    {
                        Say("  " + l);
                        ad = "yes";
                    }
                    Say(ad == "yes" ? "  -> ADB device DETECTED" : "  -> No adb device detected");
                }
                return Done(0, "fastboot detected: " + fb + " / adb detected: " + ad);
            }, true);
        }

        void OpRebootBl()
        {
            if (!NeedFb()) return;
            bool viaAdb = (_cbMethod.SelectedIndex == 0);
            StartJob("Reboot to bootloader", () =>
            {
                bool ok = GoBootloader(viaAdb);
                return Done(ok ? 0 : 1, "Reboot to bootloader - " + _bmName + " method");
            }, true);
        }

        void OpGsi()
        {
            if (!NeedFb()) return;
            if (!NeedFile(_tbVbmeta, "vbmeta.img") || !NeedFile(_tbEmpty, "empty_partition.img") || !NeedFile(_tbGsi, "the GSI system image")) return;
            string vb = _tbVbmeta.Text.Trim();
            string em = _tbEmpty.Text.Trim();
            string gs = _tbGsi.Text.Trim();
            if (!Confirm("WARNING: this erases and replaces system, product and system_ext.\n" +
                         "A factory reset is required afterwards - ALL USER DATA will be lost.\n\n" +
                         "vbmeta:  " + vb + "\nempty:   " + em + "\nsystem:  " + gs + "\n\nContinue?")) return;
            StartJob("GSI installation", () => GsiJob(vb, em, gs), true);
        }

        int GsiJob(string vb, string em, string gs)
        {
            const string W = "GSI installation";
            string step;
            Say("");
            if (!WaitFb(1))
            {
                step = "adb devices";
                Say("  [1/11] ADB device detection");
                if (!AdbAllow()) return StepFail(W, step);
                step = "adb reboot bootloader";
                Say("  [2/11] adb reboot bootloader");
                if (Exec("adb.exe", "reboot bootloader") != 0) return StepFail(W, step);
                if (!Sleep(4) || !WaitFb(30)) return StepFail(W, step);
                if (!Sleep(3)) return StepFail(W, step);
            }
            else
            {
                Say("  Fastboot device already detected - steps 1 and 2 skipped.");
            }
            step = "flash vbmeta";
            Say("  [3/11] fastboot flash --disable-verity --disable-verification vbmeta");
            if (Exec("fastboot.exe", "flash --disable-verity --disable-verification vbmeta " + Q(vb)) != 0) return StepFail(W, step);
            step = "reboot fastboot";
            Say("  [4/11] fastboot reboot fastboot");
            if (Exec("fastboot.exe", "reboot fastboot") != 0) return StepFail(W, step);
            if (!Sleep(5) || !WaitFb(30)) return StepFail(W, step);
            step = "erase system";
            Say("  [5/11] fastboot erase system");
            if (Exec("fastboot.exe", "erase system") != 0) return StepFail(W, step);
            step = "flash product";
            Say("  [6/11] fastboot flash product (empty_partition.img)");
            if (Exec("fastboot.exe", "flash product " + Q(em)) != 0) return StepFail(W, step);
            step = "flash system_ext";
            Say("  [7/11] fastboot flash system_ext (empty_partition.img)");
            if (Exec("fastboot.exe", "flash system_ext " + Q(em)) != 0) return StepFail(W, step);
            step = "flash system";
            Say("  [8/11] fastboot flash system (GSI image)");
            if (Exec("fastboot.exe", "flash system " + Q(gs)) != 0) return StepFail(W, step);
            step = "reboot recovery";
            Say("  [9/11] fastboot reboot recovery");
            if (Exec("fastboot.exe", "reboot recovery") != 0) return StepFail(W, step);
            Say("");
            Say(new string('-', 76));
            SayC("  Flashing finished - the phone is booting into recovery.", _green);
            Say("  Complete the last two steps on the phone:");
            Say("    [10/11]  Wipe data / factory reset");
            Say("    [11/11]  Reboot system now");
            Say(new string('-', 76));
            return Done(0, "GSI flashed - finish on the phone in recovery: wipe data / factory reset, then reboot system");
        }

        void OpLock(bool unlock)
        {
            if (!NeedFb()) return;
            string nm = unlock ? "Bootloader unlock" : "Bootloader relock";
            string verb = unlock ? "unlock" : "relock";
            string warn = unlock
                ? "WARNING: unlocking wipes ALL user data.\nConfirm on the device screen if it asks."
                : "WARNING: relocking wipes ALL user data.\nOnly relock with stock, unmodified firmware - a GSI, root or custom image on the device can leave it unable to boot.";
            if (!Confirm(warn + "\n\nContinue?")) return;
            StartJob(nm, () => Done(Exec("fastboot.exe", "flashing " + verb), nm), true);
        }

        void OpRoot()
        {
            if (!NeedFb() || !NeedFile(_tbBoot, "the root (boot) image")) return;
            string img = _tbBoot.Text.Trim();
            if (!Confirm("FLASH boot from:\n" + img + "\n\nContinue?")) return;
            StartJob("Root image installation", () => Done(Exec("fastboot.exe", "flash boot " + Q(img)), "Root image installation (boot: " + img + ")"), true);
        }

        void OpVerity()
        {
            if (!NeedFb() || !NeedFile(_tbVbmeta, "vbmeta.img")) return;
            string vb = _tbVbmeta.Text.Trim();
            if (!Confirm("FLASH vbmeta from:\n" + vb + "\n\nVerity and verification will be disabled.\n\nContinue?")) return;
            StartJob("Disable verity and verification", () =>
            {
                const string W = "Disable verity and verification";
                string step = "reboot fastboot";
                Say("  [1/2] fastboot reboot fastboot");
                if (Exec("fastboot.exe", "reboot fastboot") != 0) return StepFail(W, step);
                if (!Sleep(5) || !WaitFb(30)) return StepFail(W, step);
                step = "flash vbmeta";
                Say("  [2/2] fastboot --disable-verity --disable-verification flash vbmeta");
                if (Exec("fastboot.exe", "--disable-verity --disable-verification flash vbmeta " + Q(vb)) != 0) return StepFail(W, step);
                return Done(0, "Disable verity and verification (vbmeta: " + vb + ")");
            }, true);
        }

        void OpAutoRoot()
        {
            if (!NeedFb()) return;
            if (!NeedFile(_tbBoot, "the PATCHED root (boot) image") || !NeedFile(_tbVbmeta, "the STOCK vbmeta image")) return;
            DialogResult dr = MessageBox.Show(this,
                "Before starting, make sure:\n" +
                "  - the bootloader is UNLOCKED\n" +
                "  - the root image is the PATCHED boot image\n" +
                "  - vbmeta is the STOCK vbmeta image\n\n" +
                "Is the bootloader unlocked?",
                "Automated root deployment", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (dr != DialogResult.Yes)
            {
                Info("Unlock the bootloader first with the Unlock bootloader button, then run Automated root again.");
                return;
            }
            string boot = _tbBoot.Text.Trim();
            string vb = _tbVbmeta.Text.Trim();
            bool viaAdb = (_cbMethod.SelectedIndex == 0);
            if (!Confirm("patched root:  " + boot + "\nstock vbmeta:  " + vb + "\n\nStart the automatic process? Do not unplug the device.")) return;
            StartJob("Automated root deployment", () =>
            {
                const string W = "Automated root deployment";
                Say("  [1/4] Reboot to bootloader");
                if (!GoBootloader(viaAdb))
                {
                    SayC("  Could not reach the bootloader - process stopped.", _red);
                    return Done(1, "Could not reach the bootloader - " + _bmName + " method");
                }
                Say("");
                string step = "flash boot";
                Say("  [2/4] fastboot flash boot");
                if (Exec("fastboot.exe", "flash boot " + Q(boot)) != 0) return StepFail(W, step);
                step = "disable vbmeta";
                Say("  [3/4] fastboot --disable-verity --disable-verification flash vbmeta");
                if (Exec("fastboot.exe", "--disable-verity --disable-verification flash vbmeta " + Q(vb)) != 0) return StepFail(W, step);
                Say("  [4/4] fastboot reboot");
                int rc = Exec("fastboot.exe", "reboot");
                Say("");
                SayC("  Root deployment finished - the device is rebooting.", _green);
                return Done(rc, W + " - " + _bmName + " method (boot: " + boot + " / vbmeta: " + vb + ")");
            }, true);
        }

        void OpSlot(string slot)
        {
            if (!NeedFb()) return;
            if (!Confirm("Make slot " + slot.ToUpperInvariant() + " the ACTIVE slot?")) return;
            string nm = "Active slot selection " + slot;
            StartJob(nm, () =>
            {
                Say("  > fastboot devices");
                foreach (string l in FbDevices()) Say("  " + l);
                if (!WaitFb(1))
                {
                    Say("");
                    Say("  No fastboot device detected.");
                    string st = FindTool("adb.exe") == null ? "" : AdbState();
                    if (st.Length == 0)
                    {
                        SayC("  No device found. Connect the device in fastboot mode and try again.", _red);
                        return Done(1, "No device found");
                    }
                    Say("  adb device found - state: " + st);
                    if (!AskYesNo("An adb device was found (state: " + st + ").\n\nReboot it to the bootloader now?"))
                    {
                        return Done(1, "Cancelled - no fastboot device");
                    }
                    Exec("adb.exe", "reboot bootloader");
                    if (!Sleep(4) || !WaitFb(20))
                    {
                        SayC("  No device found. Connect the device in fastboot mode and try again.", _red);
                        return Done(1, "No device found");
                    }
                }
                Say("");
                Say("  Fastboot device detected.");
                return Done(Exec("fastboot.exe", "--set-active=" + slot), nm);
            }, true);
        }

        void OpSlotCheck()
        {
            if (!NeedFb()) return;
            StartJob("Check active slot", () => Done(Exec("fastboot.exe", "getvar current-slot"), "Check active slot"), false);
        }

        void OpFbReboot()
        {
            if (!NeedFb()) return;
            StartJob("Reboot device", () => Done(Exec("fastboot.exe", "reboot"), "Reboot device"), false);
        }

        // ---------------------------------------------------------------- Transsion debloat (ADB)

        void SetDebCounts(HashSet<string> inst)
        {
            int st = 0, si = 0, at = 0, ai = 0;
            foreach (DbItem it in _db)
            {
                at++;
                bool has = (inst != null && inst.Contains(it.Pkg));
                if (has) ai++;
                if (!it.Aio)
                {
                    st++;
                    if (has) si++;
                }
            }
            string txt;
            if (inst == null)
                txt = "Safe list: " + st + " packages      All-in-one list: " + at + " packages      (press Scan phone to see what is installed)";
            else
                txt = "Safe list: " + st + " packages, " + si + " installed on the phone      All-in-one list: " + at + " packages, " + ai + " installed on the phone";
            UiSet(_lblDeb, txt);
        }

        static void ParsePkgs(string text, HashSet<string> set)
        {
            foreach (string l in text.Split('\n'))
            {
                string t = l.Trim();
                if (t.StartsWith("package:", StringComparison.Ordinal)) set.Add(t.Substring(8).Trim());
            }
        }

        static string LastLine(string s)
        {
            string last = "";
            foreach (string l in s.Split('\n'))
            {
                string t = l.Trim();
                if (t.Length > 0) last = t;
            }
            return last;
        }

        // reads the package lists from the phone: inst = installed now, known = also removed ones
        bool ScanPhone(out HashSet<string> inst, out HashSet<string> known)
        {
            inst = new HashSet<string>();
            known = new HashSet<string>();
            string a = Grab("adb.exe", "exec-out pm list packages");
            if (a.Trim().Length < 10) a = Grab("adb.exe", "shell pm list packages");
            if (a.Trim().Length < 10) return false;
            string b = Grab("adb.exe", "exec-out pm list packages -u");
            if (b.Trim().Length < 10) b = Grab("adb.exe", "shell pm list packages -u");
            ParsePkgs(a, inst);
            ParsePkgs(b, known);
            foreach (string s in inst) known.Add(s);
            return true;
        }

        void OpScan()
        {
            if (!NeedAdb()) return;
            StartJob("Scan phone", () =>
            {
                if (!AdbAllow()) return Done(1, "No authorized adb device");
                HashSet<string> inst, known;
                if (!ScanPhone(out inst, out known))
                {
                    SayC("  Could not read the app list from the phone.", _red);
                    return Done(1, "Could not read the app list");
                }
                SetDebCounts(inst);
                Say("");
                Say("  Scan finished - " + inst.Count + " packages on the phone.");
                return Done(0, "Scan phone");
            }, false);
        }

        void OpDebloat(string mode)
        {
            if (!NeedAdb()) return;
            int safeN = 0;
            foreach (DbItem it in _db)
            {
                if (!it.Aio) safeN++;
            }
            string name;
            string msg;
            if (mode == "SAFE")
            {
                name = "Transsion safe remove";
                msg = "Removes the " + safeN + " apps in the safe list for the current user:\n" +
                      "ads, promos, app stores, assistants, wallpapers and Google / Facebook extras.\n" +
                      "App data is kept - Restore brings the apps back.";
            }
            else if (mode == "ALL")
            {
                name = "Transsion all-in-one remove";
                msg = "Removes all " + _db.Count + " apps in the list for the current user.\n\n" +
                      "This includes extended apps that some features depend on: keyboard, file manager, browser, " +
                      "Phone Master / Manager, cloud, weather, Google app and Photos. Keep a replacement for the ones you still need.\n\n" +
                      "App data is kept - Restore brings the apps back.";
            }
            else
            {
                name = "Transsion restore";
                msg = "Brings back every listed app that was removed for the current user.\n" +
                      "Apps that are already installed or not on this phone are skipped.";
            }
            if (!Confirm(msg + "\n\nContinue?")) return;
            StartJob(name, () => DebloatJob(mode, name), true);
        }

        int DebloatJob(string mode, string name)
        {
            bool restore = (mode == "RESTORE");
            bool all = (mode != "SAFE");
            if (!AdbAllow()) return Done(1, name + ": no authorized adb device");
            HashSet<string> inst, known;
            if (!ScanPhone(out inst, out known))
            {
                SayC("  Could not read the app list from the phone.", _red);
                return Done(1, name + ": could not read the app list");
            }
            SetDebCounts(inst);
            int rt = 0;
            foreach (DbItem it in _db)
            {
                if (all || !it.Aio) rt++;
            }
            int ok = 0, skip = 0, fail = 0, n = 0;
            string lastCat = null;
            foreach (DbItem it2 in _db)
            {
                if (_cancel) break;
                if (it2.Aio && !all) continue;
                if (it2.Cat != lastCat)
                {
                    lastCat = it2.Cat;
                    Say("");
                    SayC("  " + it2.Cat, _t.Accent);
                }
                n++;
                string tag = string.Format("  [{0,3}/{1,3}] ", n, rt);
                bool isInst = inst.Contains(it2.Pkg);
                bool isKnown = known.Contains(it2.Pkg);
                if (!restore)
                {
                    if (!isInst)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already removed or not on this phone", _yel);
                        continue;
                    }
                    string res = Grab("adb.exe", "shell pm uninstall -k --user 0 " + it2.Pkg).Trim();
                    if (res.IndexOf("Success", StringComparison.Ordinal) >= 0)
                    {
                        ok++;
                        inst.Remove(it2.Pkg);
                        SayC(tag + "REMOVED   " + it2.Pkg, _green);
                    }
                    else if (res.IndexOf("not installed", StringComparison.Ordinal) >= 0)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already removed or not on this phone", _yel);
                    }
                    else
                    {
                        fail++;
                        SayC(tag + "FAILED    " + it2.Pkg + "  " + LastLine(res), _red);
                    }
                }
                else
                {
                    if (isInst)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already installed", _yel);
                    }
                    else if (!isKnown)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - not on this phone", _yel);
                    }
                    else
                    {
                        string res2 = Grab("adb.exe", "shell cmd package install-existing --user 0 " + it2.Pkg).Trim();
                        if (res2.IndexOf("installed for user", StringComparison.Ordinal) >= 0)
                        {
                            ok++;
                            inst.Add(it2.Pkg);
                            SayC(tag + "RESTORED  " + it2.Pkg, _green);
                        }
                        else
                        {
                            fail++;
                            SayC(tag + "FAILED    " + it2.Pkg + "  " + LastLine(res2), _red);
                        }
                    }
                }
            }
            Say("");
            Say(new string('-', 76));
            Say("  " + (restore ? "Restored" : "Removed") + " : " + ok + "     Skipped : " + skip + "     Failed : " + fail + "     of " + rt);
            SetDebCounts(inst);
            int rc = (fail > 0 && ok == 0) ? 1 : 0;
            return Done(rc, name + ": " + (restore ? "restored " : "removed ") + ok + " / skipped " + skip + " / failed " + fail + " of " + rt);
        }

        // ---------------------------------------------------------------- logs

        void ShowLogFolder()
        {
            _lblFolder.Text = "Folder:  " + _logFolder;
        }

        void ChangeLogFolder()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Select the folder for logs and screenshots";
                if (Directory.Exists(_logFolder)) d.SelectedPath = _logFolder;
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    _logFolder = d.SelectedPath;
                    ShowLogFolder();
                    SaveSettings();
                }
            }
        }

        void ResetLogFolder()
        {
            _logFolder = Path.Combine(_appDir, "flash_logs");
            ShowLogFolder();
            SaveSettings();
        }

        void OpenLogFolder()
        {
            try
            {
                Directory.CreateDirectory(_logFolder);
                Process.Start("explorer.exe", Q(_logFolder));
            }
            catch (Exception ex) { Warn(ex.Message); }
        }

        void OpenLastLog()
        {
            try
            {
                string best = null;
                DateTime bt = DateTime.MinValue;
                if (Directory.Exists(_logFolder))
                {
                    foreach (string f in Directory.GetFiles(_logFolder, "*_screen_log.txt"))
                    {
                        DateTime w = File.GetLastWriteTime(f);
                        if (best == null || w > bt)
                        {
                            best = f;
                            bt = w;
                        }
                    }
                }
                if (best == null)
                {
                    Info("No log saved yet.");
                    return;
                }
                Process.Start("notepad.exe", Q(best));
            }
            catch (Exception ex) { Warn(ex.Message); }
        }
    }
}
