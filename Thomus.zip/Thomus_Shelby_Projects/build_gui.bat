@echo off
setlocal
title Build gui.exe
cd /d "%~dp0"

rem Compiles GUI.cs into gui.exe with the C# compiler that ships with Windows (.NET Framework 4.x).
rem Nothing to install.

set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo The .NET Framework 4 compiler was not found on this PC.
    echo Install the .NET Framework 4.8 runtime from Microsoft, then run this file again.
    pause
    exit /b 1
)
if not exist "GUI.cs" (
    echo GUI.cs was not found. Keep it in the same folder as this file.
    pause
    exit /b 1
)

echo Building gui.exe ...
"%CSC%" /nologo /target:winexe /optimize+ /warn:1 /out:gui.exe /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll GUI.cs
if errorlevel 1 (
    echo.
    echo Build FAILED - the error lines above say what is wrong.
    pause
    exit /b 1
)

echo.
echo Done: %~dp0gui.exe
echo Put gui.exe in the same folder as antumbra.exe. adb and fastboot can be in that folder or in PATH.
pause
