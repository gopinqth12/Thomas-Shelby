        // ---------------------------------------------------------------- theme painting

        void ApplyTheme()
        {
            _t = CurrentTheme();
            bool light = Lum(_t.Bg) > 0.55;
            _green = Theme.H(light ? "1E8E3E" : "3DDC84");
            _red = Theme.H(light ? "C5221F" : "FF5A5F");
            _yel = Theme.H(light ? "9A5B00" : "F5C84C");
            BackColor = _t.Bg;
            ForeColor = _t.Fg;
            PaintTree(this);
            _log.BackColor = _t.Input;
            _log.ForeColor = _t.Fg;
            ApplyLogFont();
            if (_log.TextLength > 0)
            {
                _log.SelectAll();
                _log.SelectionColor = _t.Fg;
                _log.SelectionStart = _log.TextLength;
                _log.SelectionLength = 0;
            }
            foreach (Button cb in _custBtns) cb.Enabled = (_themeIdx >= _themes.Count);
            UpdateNav();
            UpdateToolStatus();
        }

        void PaintTree(Control c)
        {
            string role = c.Tag as string;
            if (c is Button)
            {
                Button b = (Button)c;
                b.FlatStyle = FlatStyle.Flat;
                b.UseVisualStyleBackColor = false;
                if (role == "nav")
                {
                    b.FlatAppearance.BorderSize = 0;
                    b.BackColor = _t.Panel;
                    b.ForeColor = _t.Fg;
                }
                else
                {
                    Color edge = role == "danger" ? _red : (role == "write" ? _t.Accent : _t.Muted);
                    b.FlatAppearance.BorderSize = 1;
                    b.FlatAppearance.BorderColor = edge;
                    b.BackColor = _t.Panel;
                    b.ForeColor = role == "danger" ? _red : (role == "write" ? _t.Accent : _t.Fg);
                }
                b.FlatAppearance.MouseOverBackColor = Blend(_t.Panel, _t.Fg, 0.12);
                b.FlatAppearance.MouseDownBackColor = Blend(_t.Panel, _t.Fg, 0.22);
            }
            else if (c is TextBox || c is ComboBox || c is NumericUpDown || c is RichTextBox)
            {
                c.BackColor = _t.Input;
                c.ForeColor = _t.Fg;
            }
            else if (c is Label)
            {
                c.ForeColor = role == "muted" ? _t.Muted : (role == "accent" ? _t.Accent : _t.Fg);
                c.BackColor = Color.Transparent;
            }
            else if (c is CheckBox)
            {
                c.ForeColor = _t.Fg;
                c.BackColor = Color.Transparent;
            }
            else if (c is ProgressBar)
            {
                // keep the system look
            }
            else
            {
                if (role == "panel") c.BackColor = _t.Panel;
                else if (role == "input") c.BackColor = _t.Input;
                else c.BackColor = _t.Bg;
                c.ForeColor = _t.Fg;
            }
            foreach (Control k in c.Controls) PaintTree(k);
        }

        void ApplyLogFont()
        {
            try { _log.Font = new Font(_logFont, _logSize); }
            catch (Exception) { _log.Font = new Font(FontFamily.GenericMonospace, _logSize); }
        }

        void UpdateNav()
        {
            for (int i = 0; i < _navBtns.Length; i++)
            {
                bool on = (i == _page);
                _navBtns[i].BackColor = on ? Blend(_t.Panel, _t.Accent, 0.16) : _t.Panel;
                _navBtns[i].ForeColor = on ? _t.Accent : _t.Fg;
                _navBtns[i].FlatAppearance.MouseOverBackColor = Blend(_t.Panel, _t.Fg, 0.1);
            }
        }

        void ShowPage(int i)
        {
            _page = i;
            for (int k = 0; k < _pages.Length; k++) _pages[k].Visible = (k == i);
            if (_t != null) UpdateNav();
        }

        void UpdateToolStatus()
        {
            SetSt(_stT, "antumbra", FindTool("antumbra.exe") != null);
            SetSt(_stA, "adb", FindTool("adb.exe") != null);
            SetSt(_stF, "fastboot", FindTool("fastboot.exe") != null);
        }

        void SetSt(Label l, string name, bool ok)
        {
            l.Text = (ok ? "\u25CF " : "\u25CB ") + name;
            l.ForeColor = ok ? _green : _red;
        }

        void Welcome()
        {
            SayC("Flash Tool v" + Version + "  by Thomus Shelby", _t.Accent);
            Say("Working folder: " + _appDir);
            ToolLine("antumbra.exe");
            ToolLine("adb.exe");
            ToolLine("fastboot.exe");
            Say("");
        }

        void ToolLine(string name)
        {
            string p = FindTool(name);
            if (p == null) SayC("  " + name + " : not found - put it next to this app or add it to PATH", _red);
            else Say("  " + name + " : " + p);
        }

        // ---------------------------------------------------------------- output log

        // mode 0 = normal line, 1 = progress line (replaced by the next write), 2 = finish the current progress line
        void UiLog(string s, Color c, int mode)
        {
            if (InvokeRequired)
            {
                try { BeginInvoke(new MethodInvoker(delegate { UiLog(s, c, mode); })); }
                catch (Exception) { }
                return;
            }
            if (_progStart >= 0)
            {
                if (mode == 2)
                {
                    _log.AppendText("\n");
                    _progStart = -1;
                    ScrollEnd();
                    return;
                }
                _log.Select(_progStart, _log.TextLength - _progStart);
                _log.SelectedText = "";
                _progStart = -1;
            }
            if (mode == 2) return;
            if (_log.TextLength > 400000)
            {
                _log.Select(0, 100000);
                _log.SelectedText = "";
            }
            int start = _log.TextLength;
            _log.SelectionStart = start;
            _log.SelectionLength = 0;
            _log.SelectionColor = c;
            _log.AppendText(mode == 0 ? s + "\n" : s);
            if (mode == 1) _progStart = start;
            ScrollEnd();
        }

        void ScrollEnd()
        {
            _log.SelectionStart = _log.TextLength;
            _log.SelectionLength = 0;
            _log.ScrollToCaret();
        }

        void Say(string s) { UiLog(s, _t.Fg, 0); }

        void SayC(string s, Color c) { UiLog(s, c, 0); }

        void UiSet(Control c, string text)
        {
            if (InvokeRequired)
            {
                try { BeginInvoke(new MethodInvoker(delegate { c.Text = text; })); }
                catch (Exception) { }
                return;
            }
            c.Text = text;
        }

        // ---------------------------------------------------------------- running tools

        void EmitProc(string text, bool progress)
        {
            text = Ansi.Replace(text, "");
            if (progress && text.Trim().Length == 0) return;
            Color c = _t.Fg;
            if (text.IndexOf("FAILED", StringComparison.Ordinal) >= 0 || text.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0) c = _red;
            else if (text.IndexOf("OKAY", StringComparison.Ordinal) >= 0) c = _green;
            UiLog("  " + text, c, progress ? 1 : 0);
        }

        // Reads a tool's output live. A lone carriage return means a progress line that the next write replaces.
        void PumpLive(StreamReader r)
        {
            StringBuilder line = new StringBuilder();
            bool cr = false;
            int ch;
            while ((ch = r.Read()) != -1)
            {
                char c = (char)ch;
                if (c == '\r')
                {
                    if (line.Length > 0)
                    {
                        EmitProc(line.ToString(), true);
                        line.Length = 0;
                    }
                    cr = true;
                }
                else if (c == '\n')
                {
                    if (line.Length > 0) EmitProc(line.ToString(), false);
                    else if (cr) UiLog("", _t.Fg, 2);
                    else EmitProc("", false);
                    line.Length = 0;
                    cr = false;
                }
                else
                {
                    line.Append(c);
                    cr = false;
                }
            }
            if (line.Length > 0) EmitProc(line.ToString(), false);
        }

        void Pump(StreamReader r, bool live, StringBuilder cap)
        {
            try
            {
                if (live)
                {
                    PumpLive(r);
                }
                else
                {
                    string s = r.ReadToEnd();
                    lock (cap)
                    {
                        cap.Append(s);
                        cap.Append('\n');
                    }
                }
            }
            catch (Exception) { }
        }

        int RunProc(string tool, string args, bool live, StringBuilder cap, int timeoutMs)
        {
            string path = FindTool(tool);
            if (path == null)
            {
                if (live) SayC("  " + tool + " not found.", _red);
                return 9009;
            }
            ProcessStartInfo psi = new ProcessStartInfo(path, args);
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.StandardOutputEncoding = Encoding.UTF8;
            psi.StandardErrorEncoding = Encoding.UTF8;
            psi.WorkingDirectory = _appDir;
            psi.EnvironmentVariables["NO_COLOR"] = "1";
            Process p = new Process();
            p.StartInfo = psi;
            try
            {
                p.Start();
            }
            catch (Exception ex)
            {
                SayC("  Could not start " + tool + ": " + ex.Message, _red);
                return 9009;
            }
            if (live) _proc = p;
            Thread tOut = new Thread(() => Pump(p.StandardOutput, live, cap));
            Thread tErr = new Thread(() => Pump(p.StandardError, live, cap));
            tOut.IsBackground = true;
            tErr.IsBackground = true;
            tOut.Start();
            tErr.Start();
            int code;
            if (timeoutMs > 0 && !p.WaitForExit(timeoutMs))
            {
                try { p.Kill(); } catch (Exception) { }
                code = -1;
            }
            else
            {
                p.WaitForExit();
                code = p.ExitCode;
            }
            tOut.Join(3000);
            tErr.Join(3000);
            if (live) _proc = null;
            try { p.Dispose(); } catch (Exception) { }
            return code;
        }

        // runs a tool and shows its output in the log
        int Exec(string tool, string args)
        {
            SayC("> " + Path.GetFileNameWithoutExtension(tool) + " " + args, _t.Accent);
            return RunProc(tool, args, true, null, 0);
        }

        // runs a tool quietly and returns its output
        string Grab(string tool, string args)
        {
            StringBuilder sb = new StringBuilder();
            RunProc(tool, args, false, sb, 30000);
            return sb.ToString();
        }

        string FindTool(string name)
        {
            string n = name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? name : name + ".exe";
            try
            {
                string local = Path.Combine(_appDir, n);
                if (File.Exists(local)) return local;
            }
            catch (Exception) { }
            string pathVar = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (string d in pathVar.Split(';'))
            {
                try
                {
                    string dir = d.Trim().Trim('"');
                    if (dir.Length == 0) continue;
                    string full = Path.Combine(dir, n);
                    if (File.Exists(full)) return full;
                }
                catch (Exception) { }
            }
            return null;
        }

        void KillProc()
        {
            Process p = _proc;
            if (p == null) return;
            try
            {
                ProcessStartInfo k = new ProcessStartInfo("taskkill", "/PID " + p.Id + " /T /F");
                k.CreateNoWindow = true;
                k.UseShellExecute = false;
                Process kp = Process.Start(k);
                if (kp != null) kp.WaitForExit(3000);
            }
            catch (Exception) { }
            try { if (!p.HasExited) p.Kill(); } catch (Exception) { }
        }

        // quotes one command line argument
        static string Q(string s)
        {
            if (s == null) s = "";
            int trailing = 0;
            for (int i = s.Length - 1; i >= 0 && s[i] == '\\'; i--) trailing++;
            return "\"" + s.Replace("\"", "\\\"") + new string('\\', trailing) + "\"";
        }

        // ---------------------------------------------------------------- jobs

        void StartJob(string name, Func<int> body, bool save)
        {
            if (_busy) return;
            if (save && _askLog) AskFolderNow();
            _opName = name;
            _opDesc = "";
            _opRes = 0;
            _cancel = false;
            _opSave = save;
            _opStart = DateTime.Now;
            _sw = Stopwatch.StartNew();
            _lblOp.ForeColor = _t.Fg;
            SetBusy(true);
            Thread th = new Thread(() =>
            {
                int rc = 1;
                try
                {
                    rc = body();
                }
                catch (Exception ex)
                {
                    SayC("  Error: " + ex.Message, _red);
                    rc = 1;
                }
                _opRes = rc;
                try { BeginInvoke(new MethodInvoker(FinishJob)); }
                catch (Exception) { }
            });
            th.IsBackground = true;
            th.Start();
        }

        void SetBusy(bool b)
        {
            _busy = b;
            _pageHost.Enabled = !b;
            _btnStop.Enabled = b;
            _bar.Visible = b;
            if (b)
            {
                _tick.Start();
                _lblOp.Text = "Running: " + _opName;
            }
            else
            {
                _tick.Stop();
                _lblOp.Text = "Ready";
            }
        }

        static string Fmt(TimeSpan ts)
        {
            return string.Format("{0:00}:{1:00}:{2:00}", (int)ts.TotalHours, ts.Minutes, ts.Seconds);
        }

        void UpdateElapsed()
        {
            if (_busy && _sw != null) _lblOp.Text = "Running: " + _opName + "   " + Fmt(_sw.Elapsed);
        }

        int Done(int rc, string desc)
        {
            _opDesc = desc;
            return rc;
        }

        int StepFail(string what, string step)
        {
            _opDesc = what + " FAILED at step: " + step;
            SayC("  Step failed: " + step + " - stopped, remaining steps were NOT run.", _red);
            return 1;
        }

        // waits in small steps so Stop works; false = stopped
        bool Sleep(int seconds)
        {
            for (int i = 0; i < seconds * 10; i++)
            {
                if (_cancel) return false;
                Thread.Sleep(100);
            }
            return !_cancel;
        }

        // asks a question from a worker thread
        bool AskYesNo(string msg)
        {
            bool yes = false;
            Invoke(new MethodInvoker(delegate
            {
                yes = MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
            }));
            return yes;
        }

        void FinishJob()
        {
            if (_sw != null) _sw.Stop();
            TimeSpan ts = _sw != null ? _sw.Elapsed : TimeSpan.Zero;
            string dur = string.Format("{0}h {1}m {2}.{3:00}s", (int)ts.TotalHours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
            DateTime end = DateTime.Now;
            bool ok = (_opRes == 0 && !_cancel);
            string resTxt = _cancel ? "STOPPED by user" : (ok ? "SUCCESS" : "FAILED - exit code " + _opRes);
            if (_cancel && _opDesc.Length == 0) _opDesc = "Stopped by user";
            SetBusy(false);
            _lblOp.Text = _opName + ":  " + resTxt + "   (" + dur + ")";
            _lblOp.ForeColor = ok ? _green : _red;
            UpdateToolStatus();
            if (!_opSave) return;

            string dir = _logFolder;
            string safe = Regex.Replace(_opName, "[^A-Za-z0-9]+", "_").Trim('_');
            if (safe.Length == 0) safe = "operation";
            string stamp = end.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + "_" + safe;
            string f1 = Path.Combine(dir, stamp + "_1_flashing_done.png");
            string f2 = Path.Combine(dir, stamp + "_2_flashing_time.png");
            string ft = Path.Combine(dir, stamp + "_screen_log.txt");
            string err = "";
            try
            {
                Directory.CreateDirectory(dir);
                Shot(f1);
            }
            catch (Exception ex) { err = ex.Message; }

            string rule = new string('=', 76);
            Say("");
            Say(rule);
            SayC("  FLASH TOOL  -  OPERATION SUMMARY", _t.Accent);
            Say(rule);
            Say("");
            Say("  Operation   : " + _opName);
            Say("  Started     : " + _opStart.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            Say("  Finished    : " + end.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
            SayC("  Flash time  : " + dur, _yel);
            SayC("  Result      : " + resTxt, ok ? _green : _red);
            if (_opDesc.Length > 0) Say("  Details     : " + _opDesc);
            Say("");
            Say("  Saved in    : " + dir);
            if (err.Length > 0)
            {
                SayC("  Capture problem: " + err, _red);
            }
            else
            {
                Say("  Files       : " + Path.GetFileName(f1));
                Say("                " + Path.GetFileName(f2));
                Say("                " + Path.GetFileName(ft));
            }
            Say(rule);

            try
            {
                File.WriteAllText(ft, _log.Text.Replace("\r\n", "\n").Replace("\n", "\r\n") + "\r\n", new UTF8Encoding(false));
                Shot(f2);
            }
            catch (Exception ex2) { SayC("  Capture problem: " + ex2.Message, _red); }
        }

        // saves a picture of this window
        void Shot(string path)
        {
            Application.DoEvents();
            Rectangle r = Bounds;
            using (Bitmap bmp = new Bitmap(r.Width, r.Height))
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    DrawToBitmap(bmp, new Rectangle(0, 0, r.Width, r.Height));
                }
                else
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.CopyFromScreen(r.Location, Point.Empty, r.Size);
                    }
                }
                bmp.Save(path, ImageFormat.Png);
            }
        }

        void OnStop()
        {
            if (!_busy) return;
            if (!Confirm("Stop the running operation?\n\nStopping in the middle of a write can leave the device in a bad state.")) return;
            _cancel = true;
            KillProc();
            SayC("  Stopped by user.", _yel);
        }

        void CopyLog()
        {
            try
            {
                if (_log.TextLength > 0) Clipboard.SetText(_log.Text);
            }
            catch (Exception ex) { Warn(ex.Message); }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_busy)
            {
                DialogResult r = MessageBox.Show(this, "An operation is still running. Stop it and exit?", "Flash Tool",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (r != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }
                _cancel = true;
                KillProc();
            }
            SaveSettings();
            base.OnFormClosing(e);
        }

        void AskFolderNow()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Where to save the log and screenshots of this operation";
                if (Directory.Exists(_logFolder)) d.SelectedPath = _logFolder;
                if (d.ShowDialog(this) == DialogResult.OK) _logFolder = d.SelectedPath;
            }
        }

        void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (Exception) { }
        }

        // ---------------------------------------------------------------- dialogs and input checks

        void Warn(string msg)
        {
            MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        void Info(string msg)
        {
            MessageBox.Show(this, msg, "Flash Tool", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        bool Confirm(string msg)
        {
            return MessageBox.Show(this, msg, "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes;
        }

        bool NeedTool()
        {
            if (FindTool("antumbra.exe") != null) return true;
            Warn("antumbra.exe not found.\n\nPut this app in the same folder as antumbra.exe, or add it to PATH.");
            return false;
        }

        bool NeedFb()
        {
            if (FindTool("fastboot.exe") != null) return true;
            Warn("fastboot not found.\n\nInstall Android platform-tools and add it to PATH, or put this app in the platform-tools folder.");
            return false;
        }

        bool NeedAdb()
        {
            if (FindTool("adb.exe") != null) return true;
            Warn("adb not found.\n\nInstall Android platform-tools and add it to PATH, or put this app in the platform-tools folder.");
            return false;
        }

        bool NeedFile(TextBox tb, string what)
        {
            string p = tb.Text.Trim();
            if (p.Length == 0)
            {
                Warn("Select " + what + " first.");
                tb.Focus();
                return false;
            }
            if (!File.Exists(p))
            {
                Warn("File not found:\n" + p);
                tb.Focus();
                return false;
            }
            return true;
        }

        bool NeedDir(TextBox tb, string what)
        {
            string p = tb.Text.Trim();
            if (p.Length == 0)
            {
                Warn("Select " + what + " first.");
                tb.Focus();
                return false;
            }
            if (!Directory.Exists(p))
            {
                Warn("Folder not found:\n" + p);
                tb.Focus();
                return false;
            }
            return true;
        }

        bool NeedText(TextBox tb, string what)
        {
            if (tb.Text.Trim().Length > 0) return true;
            Warn("Type " + what + " first.");
            tb.Focus();
            return false;
        }

