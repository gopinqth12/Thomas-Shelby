        // ---------------------------------------------------------------- Fastboot / GSI

        void OpDetect()
        {
            if (!NeedFb()) return;
            StartJob("Device detection", () =>
            {
                string fb = "no";
                string ad = "skipped";
                Say("  > fastboot devices");
                foreach (string l in FbDevices())
                {
                    Say("  " + l);
                    fb = "yes";
                }
                Say(fb == "yes" ? "  -> Fastboot device DETECTED" : "  -> No fastboot device detected");
                Say("");
                if (FindTool("adb.exe") == null)
                {
                    Say("  adb not found - adb check skipped.");
                }
                else
                {
                    ad = "no";
                    Say("  > adb devices");
                    foreach (string l in AdbLines())
                    {
                        Say("  " + l);
                        ad = "yes";
                    }
                    Say(ad == "yes" ? "  -> ADB device DETECTED" : "  -> No adb device detected");
                }
                return Done(0, "fastboot detected: " + fb + " / adb detected: " + ad);
            }, true);
        }

        void OpRebootBl()
        {
            if (!NeedFb()) return;
            bool viaAdb = (_cbMethod.SelectedIndex == 0);
            StartJob("Reboot to bootloader", () =>
            {
                bool ok = GoBootloader(viaAdb);
                return Done(ok ? 0 : 1, "Reboot to bootloader - " + _bmName + " method");
            }, true);
        }

        void OpGsi()
        {
            if (!NeedFb()) return;
            if (!NeedFile(_tbVbmeta, "vbmeta.img") || !NeedFile(_tbEmpty, "empty_partition.img") || !NeedFile(_tbGsi, "the GSI system image")) return;
            string vb = _tbVbmeta.Text.Trim();
            string em = _tbEmpty.Text.Trim();
            string gs = _tbGsi.Text.Trim();
            if (!Confirm("WARNING: this erases and replaces system, product and system_ext.\n" +
                         "A factory reset is required afterwards - ALL USER DATA will be lost.\n\n" +
                         "vbmeta:  " + vb + "\nempty:   " + em + "\nsystem:  " + gs + "\n\nContinue?")) return;
            StartJob("GSI installation", () => GsiJob(vb, em, gs), true);
        }

        int GsiJob(string vb, string em, string gs)
        {
            const string W = "GSI installation";
            string step;
            Say("");
            if (!WaitFb(1))
            {
                step = "adb devices";
                Say("  [1/11] ADB device detection");
                if (!AdbAllow()) return StepFail(W, step);
                step = "adb reboot bootloader";
                Say("  [2/11] adb reboot bootloader");
                if (Exec("adb.exe", "reboot bootloader") != 0) return StepFail(W, step);
                if (!Sleep(4) || !WaitFb(30)) return StepFail(W, step);
                if (!Sleep(3)) return StepFail(W, step);
            }
            else
            {
                Say("  Fastboot device already detected - steps 1 and 2 skipped.");
            }
            step = "flash vbmeta";
            Say("  [3/11] fastboot flash --disable-verity --disable-verification vbmeta");
            if (Exec("fastboot.exe", "flash --disable-verity --disable-verification vbmeta " + Q(vb)) != 0) return StepFail(W, step);
            step = "reboot fastboot";
            Say("  [4/11] fastboot reboot fastboot");
            if (Exec("fastboot.exe", "reboot fastboot") != 0) return StepFail(W, step);
            if (!Sleep(5) || !WaitFb(30)) return StepFail(W, step);
            step = "erase system";
            Say("  [5/11] fastboot erase system");
            if (Exec("fastboot.exe", "erase system") != 0) return StepFail(W, step);
            step = "flash product";
            Say("  [6/11] fastboot flash product (empty_partition.img)");
            if (Exec("fastboot.exe", "flash product " + Q(em)) != 0) return StepFail(W, step);
            step = "flash system_ext";
            Say("  [7/11] fastboot flash system_ext (empty_partition.img)");
            if (Exec("fastboot.exe", "flash system_ext " + Q(em)) != 0) return StepFail(W, step);
            step = "flash system";
            Say("  [8/11] fastboot flash system (GSI image)");
            if (Exec("fastboot.exe", "flash system " + Q(gs)) != 0) return StepFail(W, step);
            step = "reboot recovery";
            Say("  [9/11] fastboot reboot recovery");
            if (Exec("fastboot.exe", "reboot recovery") != 0) return StepFail(W, step);
            Say("");
            Say(new string('-', 76));
            SayC("  Flashing finished - the phone is booting into recovery.", _green);
            Say("  Complete the last two steps on the phone:");
            Say("    [10/11]  Wipe data / factory reset");
            Say("    [11/11]  Reboot system now");
            Say(new string('-', 76));
            return Done(0, "GSI flashed - finish on the phone in recovery: wipe data / factory reset, then reboot system");
        }

        void OpLock(bool unlock)
        {
            if (!NeedFb()) return;
            string nm = unlock ? "Bootloader unlock" : "Bootloader relock";
            string verb = unlock ? "unlock" : "relock";
            string warn = unlock
                ? "WARNING: unlocking wipes ALL user data.\nConfirm on the device screen if it asks."
                : "WARNING: relocking wipes ALL user data.\nOnly relock with stock, unmodified firmware - a GSI, root or custom image on the device can leave it unable to boot.";
            if (!Confirm(warn + "\n\nContinue?")) return;
            StartJob(nm, () => Done(Exec("fastboot.exe", "flashing " + verb), nm), true);
        }

        void OpRoot()
        {
            if (!NeedFb() || !NeedFile(_tbBoot, "the root (boot) image")) return;
            string img = _tbBoot.Text.Trim();
            if (!Confirm("FLASH boot from:\n" + img + "\n\nContinue?")) return;
            StartJob("Root image installation", () => Done(Exec("fastboot.exe", "flash boot " + Q(img)), "Root image installation (boot: " + img + ")"), true);
        }

        void OpVerity()
        {
            if (!NeedFb() || !NeedFile(_tbVbmeta, "vbmeta.img")) return;
            string vb = _tbVbmeta.Text.Trim();
            if (!Confirm("FLASH vbmeta from:\n" + vb + "\n\nVerity and verification will be disabled.\n\nContinue?")) return;
            StartJob("Disable verity and verification", () =>
            {
                const string W = "Disable verity and verification";
                string step = "reboot fastboot";
                Say("  [1/2] fastboot reboot fastboot");
                if (Exec("fastboot.exe", "reboot fastboot") != 0) return StepFail(W, step);
                if (!Sleep(5) || !WaitFb(30)) return StepFail(W, step);
                step = "flash vbmeta";
                Say("  [2/2] fastboot --disable-verity --disable-verification flash vbmeta");
                if (Exec("fastboot.exe", "--disable-verity --disable-verification flash vbmeta " + Q(vb)) != 0) return StepFail(W, step);
                return Done(0, "Disable verity and verification (vbmeta: " + vb + ")");
            }, true);
        }

        void OpAutoRoot()
        {
            if (!NeedFb()) return;
            if (!NeedFile(_tbBoot, "the PATCHED root (boot) image") || !NeedFile(_tbVbmeta, "the STOCK vbmeta image")) return;
            DialogResult dr = MessageBox.Show(this,
                "Before starting, make sure:\n" +
                "  - the bootloader is UNLOCKED\n" +
                "  - the root image is the PATCHED boot image\n" +
                "  - vbmeta is the STOCK vbmeta image\n\n" +
                "Is the bootloader unlocked?",
                "Automated root deployment", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (dr != DialogResult.Yes)
            {
                Info("Unlock the bootloader first with the Unlock bootloader button, then run Automated root again.");
                return;
            }
            string boot = _tbBoot.Text.Trim();
            string vb = _tbVbmeta.Text.Trim();
            bool viaAdb = (_cbMethod.SelectedIndex == 0);
            if (!Confirm("patched root:  " + boot + "\nstock vbmeta:  " + vb + "\n\nStart the automatic process? Do not unplug the device.")) return;
            StartJob("Automated root deployment", () =>
            {
                const string W = "Automated root deployment";
                Say("  [1/4] Reboot to bootloader");
                if (!GoBootloader(viaAdb))
                {
                    SayC("  Could not reach the bootloader - process stopped.", _red);
                    return Done(1, "Could not reach the bootloader - " + _bmName + " method");
                }
                Say("");
                string step = "flash boot";
                Say("  [2/4] fastboot flash boot");
                if (Exec("fastboot.exe", "flash boot " + Q(boot)) != 0) return StepFail(W, step);
                step = "disable vbmeta";
                Say("  [3/4] fastboot --disable-verity --disable-verification flash vbmeta");
                if (Exec("fastboot.exe", "--disable-verity --disable-verification flash vbmeta " + Q(vb)) != 0) return StepFail(W, step);
                Say("  [4/4] fastboot reboot");
                int rc = Exec("fastboot.exe", "reboot");
                Say("");
                SayC("  Root deployment finished - the device is rebooting.", _green);
                return Done(rc, W + " - " + _bmName + " method (boot: " + boot + " / vbmeta: " + vb + ")");
            }, true);
        }

        void OpSlot(string slot)
        {
            if (!NeedFb()) return;
            if (!Confirm("Make slot " + slot.ToUpperInvariant() + " the ACTIVE slot?")) return;
            string nm = "Active slot selection " + slot;
            StartJob(nm, () =>
            {
                Say("  > fastboot devices");
                foreach (string l in FbDevices()) Say("  " + l);
                if (!WaitFb(1))
                {
                    Say("");
                    Say("  No fastboot device detected.");
                    string st = FindTool("adb.exe") == null ? "" : AdbState();
                    if (st.Length == 0)
                    {
                        SayC("  No device found. Connect the device in fastboot mode and try again.", _red);
                        return Done(1, "No device found");
                    }
                    Say("  adb device found - state: " + st);
                    if (!AskYesNo("An adb device was found (state: " + st + ").\n\nReboot it to the bootloader now?"))
                    {
                        return Done(1, "Cancelled - no fastboot device");
                    }
                    Exec("adb.exe", "reboot bootloader");
                    if (!Sleep(4) || !WaitFb(20))
                    {
                        SayC("  No device found. Connect the device in fastboot mode and try again.", _red);
                        return Done(1, "No device found");
                    }
                }
                Say("");
                Say("  Fastboot device detected.");
                return Done(Exec("fastboot.exe", "--set-active=" + slot), nm);
            }, true);
        }

        void OpSlotCheck()
        {
            if (!NeedFb()) return;
            StartJob("Check active slot", () => Done(Exec("fastboot.exe", "getvar current-slot"), "Check active slot"), false);
        }

        void OpFbReboot()
        {
            if (!NeedFb()) return;
            StartJob("Reboot device", () => Done(Exec("fastboot.exe", "reboot"), "Reboot device"), false);
        }

        // ---------------------------------------------------------------- Transsion debloat (ADB)

        void SetDebCounts(HashSet<string> inst)
        {
            int st = 0, si = 0, at = 0, ai = 0;
            foreach (DbItem it in _db)
            {
                at++;
                bool has = (inst != null && inst.Contains(it.Pkg));
                if (has) ai++;
                if (!it.Aio)
                {
                    st++;
                    if (has) si++;
                }
            }
            string txt;
            if (inst == null)
                txt = "Safe list: " + st + " packages      All-in-one list: " + at + " packages      (press Scan phone to see what is installed)";
            else
                txt = "Safe list: " + st + " packages, " + si + " installed on the phone      All-in-one list: " + at + " packages, " + ai + " installed on the phone";
            UiSet(_lblDeb, txt);
        }

        static void ParsePkgs(string text, HashSet<string> set)
        {
            foreach (string l in text.Split('\n'))
            {
                string t = l.Trim();
                if (t.StartsWith("package:", StringComparison.Ordinal)) set.Add(t.Substring(8).Trim());
            }
        }

        static string LastLine(string s)
        {
            string last = "";
            foreach (string l in s.Split('\n'))
            {
                string t = l.Trim();
                if (t.Length > 0) last = t;
            }
            return last;
        }

        // reads the package lists from the phone: inst = installed now, known = also removed ones
        bool ScanPhone(out HashSet<string> inst, out HashSet<string> known)
        {
            inst = new HashSet<string>();
            known = new HashSet<string>();
            string a = Grab("adb.exe", "exec-out pm list packages");
            if (a.Trim().Length < 10) a = Grab("adb.exe", "shell pm list packages");
            if (a.Trim().Length < 10) return false;
            string b = Grab("adb.exe", "exec-out pm list packages -u");
            if (b.Trim().Length < 10) b = Grab("adb.exe", "shell pm list packages -u");
            ParsePkgs(a, inst);
            ParsePkgs(b, known);
            foreach (string s in inst) known.Add(s);
            return true;
        }

        void OpScan()
        {
            if (!NeedAdb()) return;
            StartJob("Scan phone", () =>
            {
                if (!AdbAllow()) return Done(1, "No authorized adb device");
                HashSet<string> inst, known;
                if (!ScanPhone(out inst, out known))
                {
                    SayC("  Could not read the app list from the phone.", _red);
                    return Done(1, "Could not read the app list");
                }
                SetDebCounts(inst);
                Say("");
                Say("  Scan finished - " + inst.Count + " packages on the phone.");
                return Done(0, "Scan phone");
            }, false);
        }

        void OpDebloat(string mode)
        {
            if (!NeedAdb()) return;
            int safeN = 0;
            foreach (DbItem it in _db)
            {
                if (!it.Aio) safeN++;
            }
            string name;
            string msg;
            if (mode == "SAFE")
            {
                name = "Transsion safe remove";
                msg = "Removes the " + safeN + " apps in the safe list for the current user:\n" +
                      "ads, promos, app stores, assistants, wallpapers and Google / Facebook extras.\n" +
                      "App data is kept - Restore brings the apps back.";
            }
            else if (mode == "ALL")
            {
                name = "Transsion all-in-one remove";
                msg = "Removes all " + _db.Count + " apps in the list for the current user.\n\n" +
                      "This includes extended apps that some features depend on: keyboard, file manager, browser, " +
                      "Phone Master / Manager, cloud, weather, Google app and Photos. Keep a replacement for the ones you still need.\n\n" +
                      "App data is kept - Restore brings the apps back.";
            }
            else
            {
                name = "Transsion restore";
                msg = "Brings back every listed app that was removed for the current user.\n" +
                      "Apps that are already installed or not on this phone are skipped.";
            }
            if (!Confirm(msg + "\n\nContinue?")) return;
            StartJob(name, () => DebloatJob(mode, name), true);
        }

        int DebloatJob(string mode, string name)
        {
            bool restore = (mode == "RESTORE");
            bool all = (mode != "SAFE");
            if (!AdbAllow()) return Done(1, name + ": no authorized adb device");
            HashSet<string> inst, known;
            if (!ScanPhone(out inst, out known))
            {
                SayC("  Could not read the app list from the phone.", _red);
                return Done(1, name + ": could not read the app list");
            }
            SetDebCounts(inst);
            int rt = 0;
            foreach (DbItem it in _db)
            {
                if (all || !it.Aio) rt++;
            }
            int ok = 0, skip = 0, fail = 0, n = 0;
            string lastCat = null;
            foreach (DbItem it2 in _db)
            {
                if (_cancel) break;
                if (it2.Aio && !all) continue;
                if (it2.Cat != lastCat)
                {
                    lastCat = it2.Cat;
                    Say("");
                    SayC("  " + it2.Cat, _t.Accent);
                }
                n++;
                string tag = string.Format("  [{0,3}/{1,3}] ", n, rt);
                bool isInst = inst.Contains(it2.Pkg);
                bool isKnown = known.Contains(it2.Pkg);
                if (!restore)
                {
                    if (!isInst)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already removed or not on this phone", _yel);
                        continue;
                    }
                    string res = Grab("adb.exe", "shell pm uninstall -k --user 0 " + it2.Pkg).Trim();
                    if (res.IndexOf("Success", StringComparison.Ordinal) >= 0)
                    {
                        ok++;
                        inst.Remove(it2.Pkg);
                        SayC(tag + "REMOVED   " + it2.Pkg, _green);
                    }
                    else if (res.IndexOf("not installed", StringComparison.Ordinal) >= 0)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already removed or not on this phone", _yel);
                    }
                    else
                    {
                        fail++;
                        SayC(tag + "FAILED    " + it2.Pkg + "  " + LastLine(res), _red);
                    }
                }
                else
                {
                    if (isInst)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - already installed", _yel);
                    }
                    else if (!isKnown)
                    {
                        skip++;
                        SayC(tag + "SKIPPED   " + it2.Pkg + " - not on this phone", _yel);
                    }
                    else
                    {
                        string res2 = Grab("adb.exe", "shell cmd package install-existing --user 0 " + it2.Pkg).Trim();
                        if (res2.IndexOf("installed for user", StringComparison.Ordinal) >= 0)
                        {
                            ok++;
                            inst.Add(it2.Pkg);
                            SayC(tag + "RESTORED  " + it2.Pkg, _green);
                        }
                        else
                        {
                            fail++;
                            SayC(tag + "FAILED    " + it2.Pkg + "  " + LastLine(res2), _red);
                        }
                    }
                }
            }
            Say("");
            Say(new string('-', 76));
            Say("  " + (restore ? "Restored" : "Removed") + " : " + ok + "     Skipped : " + skip + "     Failed : " + fail + "     of " + rt);
            SetDebCounts(inst);
            int rc = (fail > 0 && ok == 0) ? 1 : 0;
            return Done(rc, name + ": " + (restore ? "restored " : "removed ") + ok + " / skipped " + skip + " / failed " + fail + " of " + rt);
        }

        // ---------------------------------------------------------------- logs

        void ShowLogFolder()
        {
            _lblFolder.Text = "Folder:  " + _logFolder;
        }

        void ChangeLogFolder()
        {
            using (FolderBrowserDialog d = new FolderBrowserDialog())
            {
                d.Description = "Select the folder for logs and screenshots";
                if (Directory.Exists(_logFolder)) d.SelectedPath = _logFolder;
                if (d.ShowDialog(this) == DialogResult.OK)
                {
                    _logFolder = d.SelectedPath;
                    ShowLogFolder();
                    SaveSettings();
                }
            }
        }

        void ResetLogFolder()
        {
            _logFolder = Path.Combine(_appDir, "flash_logs");
            ShowLogFolder();
            SaveSettings();
        }

        void OpenLogFolder()
        {
            try
            {
                Directory.CreateDirectory(_logFolder);
                Process.Start("explorer.exe", Q(_logFolder));
            }
            catch (Exception ex) { Warn(ex.Message); }
        }

        void OpenLastLog()
        {
            try
            {
                string best = null;
                DateTime bt = DateTime.MinValue;
                if (Directory.Exists(_logFolder))
                {
                    foreach (string f in Directory.GetFiles(_logFolder, "*_screen_log.txt"))
                    {
                        DateTime w = File.GetLastWriteTime(f);
                        if (best == null || w > bt)
                        {
                            best = f;
                            bt = w;
                        }
                    }
                }
                if (best == null)
                {
                    Info("No log saved yet.");
                    return;
                }
                Process.Start("notepad.exe", Q(best));
            }
            catch (Exception ex) { Warn(ex.Message); }
        }
    }
}
