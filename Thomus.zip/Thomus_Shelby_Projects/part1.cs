// Flash Tool GUI v2.1 - Windows Forms front end for flash_tool_V2_1.bat
// Plain C# 5, so the compiler built into Windows (csc.exe, .NET Framework 4.x) can build it.
// Build it with build_gui.bat -> gui.exe

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace FlashToolGui
{
    static class Program
    {
        [DllImport("user32.dll")]
        static extern bool SetProcessDPIAware();

        [STAThread]
        static void Main()
        {
            try { SetProcessDPIAware(); } catch (Exception) { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    class Theme
    {
        public string Name;
        public Color Bg, Panel, Input, Fg, Muted, Accent;

        public Theme(string name, string bg, string panel, string input, string fg, string muted, string accent)
        {
            Name = name; Bg = H(bg); Panel = H(panel); Input = H(input);
            Fg = H(fg); Muted = H(muted); Accent = H(accent);
        }

        public static Color H(string hex) { return ColorTranslator.FromHtml("#" + hex); }
    }

    class DbItem
    {
        public string Cat;
        public string Pkg;
        public bool Aio;
    }

    class Part
    {
        public string Name = "";
        public string Img = "";
        public string OpName = "";
        public bool Dl = true;
        public int FileLine = -1;
        public int DlLine = -1;
    }

    class MainForm : Form
    {
        const string Version = "2.1";
        const string ImgFilter = "Image (*.img)|*.img|All files|*.*";

        // Transsion debloat list. "#" starts a category, "+" marks apps that only the all-in-one remove touches.
        const string DbList = @"
#Assistants / AI
com.transsion.aivoiceassistant
com.transsion.folax
com.transsion.kolun.assistant
+com.transsion.tranvoicecommand
+com.transsion.smartrecognition
#Ads / promo / recommendation / telemetry
com.transsion.magazinelockscreen
com.transsion.magazineservice.xos
com.transsion.mtimes
com.transsion.personalizedService.xos
+com.transsion.tranengine
com.transsion.statisticalsales
+com.transsion.succ
com.transsion.wezone
+com.transsion.mol
com.idea.questionnaire
com.transsion.chromecustomization
com.android.google.adservices.api
#App stores / updaters / push
com.transsnet.store
net.bat.store
com.transsion.plat.appupdate
com.talpa.hiservice
com.transsion.gamecenter
com.transsion.themeshop
#Cleaners / utilities
+com.transsion.phonemaster
+com.transsion.phonemanager
+com.transsion.applock
com.transsion.agingfunction
com.transsion.manualguide
com.transsion.repaircard
com.transsion.carlcare
com.transsion.globalsearch
+com.transsion.scanningrecharger
com.transsion.health
+com.rlk.weathers
com.zaz.translate
+com.mediatek.mdmconfig
com.transsion.tips
+com.transsion.filemanagerx
+com.transsion.dualapp
+com.xui.xhide
+com.transsion.tranfacicon
+com.geniex.vsimhelper
#Transfer / sharing / connect
com.transsion.mobilecloner
com.transsion.letswitch
+com.transsion.cloudserver
com.transsion.pcconnect
com.talpa.share
com.transsion.wifiplaytogether
+com.transsion.audiosmartconnect
+tech.palm.find
#Launcher / browser / keyboard / media
com.talpa.hibrowser
+com.facemoji.lite.transsion
com.transsion.videoplayer.overseas
com.google.android.apps.nbu.files
com.transsion.magicshow
com.trassion.infinix.xclub
+com.android.chrome
+com.funbase.xradio
#Wallpapers / kids mode
com.transsion.livewallpaper.mecha
com.transsion.livewallpaper.saibo
com.transsion.livewallpaper.airship
com.transsion.livewallpaper.spacecraft
com.transsion.livewallpaper.pictorial
com.transsion.childmode
com.transsion.childmode.resoverlay
#Facebook / Google extras
com.facebook.services
com.facebook.appmanager
com.facebook.system
com.google.android.feedback
com.google.android.projection.gearhead
com.google.android.videos
com.google.android.apps.youtube.music
com.google.android.apps.tachyon
com.google.android.apps.wellbeing
com.google.android.gms.location.history
com.android.hotwordenrollment.xgoogle
com.android.hotwordenrollment.okgoogle
+com.google.android.apps.photos
+com.google.android.googlequicksearchbox
+com.google.android.healthconnect.controller
";

        static readonly Regex Ansi = new Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]");

        readonly string _appDir = AppDomain.CurrentDomain.BaseDirectory;
        readonly string _iniPath;
        readonly List<DbItem> _db = ParseDb();

        List<Theme> _themes;
        Theme _t;
        int _themeIdx;
        Color _custBg = Color.FromArgb(18, 20, 23);
        Color _custFg = Color.FromArgb(216, 220, 225);
        Color _custAcc = Color.FromArgb(92, 200, 224);
        Color _green, _red, _yel;
        string _logFont = "Consolas";
        float _logSize = 10f;
        string _logFolder;
        bool _askLog;
        bool _loading = true;
        string _savedDA = "";
        string _savedAuth = "";

        // controls
        RichTextBox _log;
        Label _lblOp, _lblDeb, _lblFolder, _stT, _stA, _stF;
        Button _btnStop;
        ProgressBar _bar;
        Panel _pageHost;
        Panel[] _pages;
        Button[] _navBtns;
        int _page;
        TextBox _tbDA, _tbAuth, _tbPart, _tbBackup, _tbImg, _tbScatter, _tbPreloader;
        TextBox _tbVbmeta, _tbEmpty, _tbGsi, _tbBoot;
        ComboBox _cbMethod, _cbTheme, _cbFont;
        NumericUpDown _numSize;
        CheckBox _chkAsk;
        List<Button> _custBtns = new List<Button>();
        System.Windows.Forms.Timer _tick;

        // running job
        volatile bool _busy;
        volatile bool _cancel;
        Process _proc;
        Stopwatch _sw;
        string _opName = "";
        string _opDesc = "";
        int _opRes;
        bool _opSave;
        DateTime _opStart;
        string _bmName = "";
        int _progStart = -1;

        public MainForm()
        {
            _iniPath = Path.Combine(_appDir, "flash_tool_gui.ini");
            _logFolder = Path.Combine(_appDir, "flash_logs");
            InitThemes();
            LoadSettings();
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = new Font("Segoe UI", 9.5f);
            Text = "Flash Tool v" + Version + " - by Thomus Shelby";
            ClientSize = new Size(1100, 800);
            MinimumSize = new Size(920, 660);
            StartPosition = FormStartPosition.CenterScreen;
            BuildUi();
            _tbDA.Text = _savedDA;
            _tbAuth.Text = _savedAuth;
            _loading = false;
            ApplyTheme();
            ShowPage(0);
            Shown += OnShown;
        }

        void OnShown(object sender, EventArgs e)
        {
            Rectangle wa = Screen.FromControl(this).WorkingArea;
            if (Width > wa.Width) Width = wa.Width;
            if (Height > wa.Height) Height = wa.Height;
            CenterToScreen();
            UpdateToolStatus();
            Welcome();
        }

        // ---------------------------------------------------------------- themes and settings

        void InitThemes()
        {
            _themes = new List<Theme>();
            _themes.Add(new Theme("Classic Dark", "121417", "1B1F24", "0D0F12", "D8DCE1", "7D8793", "5CC8E0"));
            _themes.Add(new Theme("Hacker Green", "050B07", "0B140D", "030604", "3CE462", "23904A", "86FFA3"));
            _themes.Add(new Theme("Ocean Blue", "0B2545", "12355F", "081D38", "EAF2FF", "8FB0D9", "FFD166"));
            _themes.Add(new Theme("Midnight Purple", "1A1033", "26184B", "120A26", "EDE7FF", "A594D6", "F5C84C"));
            _themes.Add(new Theme("Amber Terminal", "140D00", "201603", "0E0900", "FFB000", "A8740A", "FFE08A"));
            _themes.Add(new Theme("Crimson", "17080A", "240E11", "100506", "F2D4D6", "A3686C", "FF5A64"));
            _themes.Add(new Theme("Light Pro", "F1F3F5", "FFFFFF", "FFFFFF", "1F2933", "69747F", "1D5FD1"));
            _themes.Add(new Theme("Slate Gray", "2B3036", "363C44", "23272C", "EEF1F4", "9AA5B1", "F5C84C"));
            _themes.Add(new Theme("Cyber Cyan", "020E10", "07191D", "010809", "5CF0F0", "2E9C9C", "F2FFFF"));
        }

        Theme CurrentTheme()
        {
            if (_themeIdx >= 0 && _themeIdx < _themes.Count) return _themes[_themeIdx];
            Theme c = new Theme("Custom", "000000", "000000", "000000", "000000", "000000", "000000");
            c.Bg = _custBg;
            c.Fg = _custFg;
            c.Accent = _custAcc;
            c.Panel = Blend(_custBg, _custFg, 0.07);
            c.Input = Blend(_custBg, Color.Black, 0.25);
            c.Muted = Blend(_custFg, _custBg, 0.5);
            return c;
        }

        static Color Blend(Color a, Color b, double amount)
        {
            return Color.FromArgb(
                (int)(a.R + (b.R - a.R) * amount),
                (int)(a.G + (b.G - a.G) * amount),
                (int)(a.B + (b.B - a.B) * amount));
        }

        static double Lum(Color c)
        {
            return (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) / 255.0;
        }

        static Color ParseHex(string v, Color def)
        {
            try { return ColorTranslator.FromHtml("#" + v.TrimStart('#')); }
            catch (Exception) { return def; }
        }

        static string Hex(Color c)
        {
            return string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);
        }

        void LoadSettings()
        {
            try
            {
                if (!File.Exists(_iniPath)) return;
                foreach (string raw in File.ReadAllLines(_iniPath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line[0] == '#') continue;
                    int eq = line.IndexOf('=');
                    if (eq < 1) continue;
                    string k = line.Substring(0, eq).Trim().ToUpperInvariant();
                    string v = line.Substring(eq + 1).Trim();
                    int n;
                    float f;
                    switch (k)
                    {
                        case "THEME":
                            if (int.TryParse(v, out n) && n >= 0 && n <= _themes.Count) _themeIdx = n;
                            break;
                        case "CUSTBG": _custBg = ParseHex(v, _custBg); break;
                        case "CUSTFG": _custFg = ParseHex(v, _custFg); break;
                        case "CUSTACCENT": _custAcc = ParseHex(v, _custAcc); break;
                        case "LOGFONT":
                            if (v.Length > 0) _logFont = v;
                            break;
                        case "LOGFONTSIZE":
                            if (float.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out f) && f >= 8 && f <= 28) _logSize = f;
                            break;
                        case "LOGFOLDER":
                            if (v.Length > 0) _logFolder = v;
                            break;
                        case "ASKLOG": _askLog = (v == "1"); break;
                        case "DA": _savedDA = v; break;
                        case "AUTH": _savedAuth = v; break;
                    }
                }
            }
            catch (Exception) { }
        }

        void SaveSettings()
        {
            if (_loading) return;
            try
            {
                List<string> l = new List<string>();
                l.Add("# flash tool gui settings");
                l.Add("THEME=" + _themeIdx);
                l.Add("CUSTBG=" + Hex(_custBg));
                l.Add("CUSTFG=" + Hex(_custFg));
                l.Add("CUSTACCENT=" + Hex(_custAcc));
                l.Add("LOGFONT=" + _logFont);
                l.Add("LOGFONTSIZE=" + _logSize.ToString(CultureInfo.InvariantCulture));
                l.Add("LOGFOLDER=" + _logFolder);
                l.Add("ASKLOG=" + (_askLog ? "1" : "0"));
                l.Add("DA=" + _tbDA.Text.Trim());
                l.Add("AUTH=" + _tbAuth.Text.Trim());
                File.WriteAllLines(_iniPath, l.ToArray(), new UTF8Encoding(false));
            }
            catch (Exception) { }
        }

        static List<DbItem> ParseDb()
        {
            List<DbItem> list = new List<DbItem>();
            string cat = "";
            foreach (string raw in DbList.Split('\n'))
            {
                string s = raw.Trim();
                if (s.Length == 0) continue;
                if (s[0] == '#') { cat = s.Substring(1); continue; }
                DbItem it = new DbItem();
                it.Cat = cat;
                if (s[0] == '+') { it.Aio = true; s = s.Substring(1); }
                it.Pkg = s;
                list.Add(it);
            }
            return list;
        }

