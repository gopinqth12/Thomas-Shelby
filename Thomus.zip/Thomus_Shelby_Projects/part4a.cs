        // ---------------------------------------------------------------- adb / fastboot helpers (run on the worker thread)

        List<string> FbDevices()
        {
            List<string> r = new List<string>();
            foreach (string l in Grab("fastboot.exe", "devices").Split('\n'))
            {
                string t = l.Trim();
                if (t.Length > 0) r.Add(t);
            }
            return r;
        }

        // true = a fastboot device was found. Checks every 2 seconds, up to "tries" times.
        bool WaitFb(int tries)
        {
            int wt = 0;
            while (true)
            {
                if (_cancel) return false;
                if (FbDevices().Count > 0) return true;
                wt++;
                if (wt >= tries) return false;
                Say("  Waiting for the device... (" + wt + "/" + tries + ")");
                if (!Sleep(2)) return false;
            }
        }

        List<string> AdbLines()
        {
            List<string> r = new List<string>();
            foreach (string l in Grab("adb.exe", "devices").Split('\n'))
            {
                string t = l.Trim();
                if (t.Length == 0) continue;
                if (t.StartsWith("List", StringComparison.Ordinal)) continue;
                if (t.StartsWith("*", StringComparison.Ordinal)) continue;
                if (t.StartsWith("adb server", StringComparison.Ordinal)) continue;
                r.Add(t);
            }
            return r;
        }

        // device / unauthorized / offline, or "" when no adb device is connected
        string AdbState()
        {
            string st = "";
            foreach (string t in AdbLines())
            {
                string[] parts = t.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2) st = parts[1];
            }
            return st;
        }

        // waits until the phone has allowed USB debugging
        bool AdbAllow()
        {
            if (FindTool("adb.exe") == null)
            {
                SayC("  adb not found. Install Android platform-tools and add it to PATH.", _red);
                return false;
            }
            Say("");
            Exec("adb.exe", "devices");
            Say("");
            SayC("  Please allow USB debugging in your device - tap Allow on the phone screen.", _yel);
            int tr = 0;
            while (true)
            {
                string st = AdbState();
                if (st.Equals("device", StringComparison.OrdinalIgnoreCase))
                {
                    Say("  adb device authorized.");
                    return true;
                }
                tr++;
                if (st.Length == 0 && tr >= 4) break;
                if (tr >= 15) break;
                if (st.Length > 0) Say("  Device state: " + st + " - waiting for you to allow it...");
                if (!Sleep(2)) return false;
            }
            SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
            return false;
        }

        // reboots to the bootloader with the ADB or the Fastboot method and waits for it
        bool GoBootloader(bool viaAdb)
        {
            _bmName = viaAdb ? "ADB" : "Fastboot";
            if (viaAdb)
            {
                if (FindTool("adb.exe") == null)
                {
                    SayC("  adb not found. Install Android platform-tools or use the Fastboot method.", _red);
                    return false;
                }
                Say("");
                Exec("adb.exe", "devices");
                Say("");
                SayC("  Please allow USB debugging in your device - tap Allow on the phone screen.", _yel);
                int tr = 0;
                while (true)
                {
                    string st = AdbState();
                    if (st.Length == 0)
                    {
                        SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
                        return false;
                    }
                    if (st.Equals("device", StringComparison.OrdinalIgnoreCase)) break;
                    Say("  Device state: " + st + " - waiting for you to allow it...");
                    tr++;
                    if (tr >= 15)
                    {
                        SayC("  No authorized adb device found. Check the cable and allow USB debugging.", _red);
                        return false;
                    }
                    if (!Sleep(2)) return false;
                }
                Say("  adb device authorized.");
                if (Exec("adb.exe", "reboot bootloader") != 0) return false;
            }
            else
            {
                Say("");
                Exec("fastboot.exe", "devices");
                if (!WaitFb(1))
                {
                    SayC("  No fastboot device detected. Put the device in fastboot mode first.", _red);
                    return false;
                }
                if (Exec("fastboot.exe", "reboot bootloader") != 0) return false;
            }
            if (!Sleep(4)) return false;
            Say("");
            Say("  > fastboot devices  - waiting for the bootloader");
            if (!WaitFb(20))
            {
                SayC("  Bootloader not detected - stopped.", _red);
                return false;
            }
            Exec("fastboot.exe", "devices");
            Say("");
            SayC("  Bootloader detected - please wait 3-4 sec for the flashing commands...", _green);
            return Sleep(4);
        }

        // ---------------------------------------------------------------- MediaTek (antumbra)

        string AuthArg()
        {
            string a = _tbAuth.Text.Trim();
            return a.Length == 0 ? "" : " -a " + Q(a);
        }

        string DaArg()
        {
            return " -d " + Q(_tbDA.Text.Trim()) + AuthArg();
        }

        // antumbra present, DA file chosen, optional Auth file valid
        bool MtkReady()
        {
            if (!NeedTool()) return false;
            if (!NeedFile(_tbDA, "the DA file (DA_BR.bin)")) return false;
            string a = _tbAuth.Text.Trim();
            if (a.Length > 0 && !File.Exists(a))
            {
                Warn("Auth file not found:\n" + a + "\n\nClear the field to continue without it.");
                _tbAuth.Focus();
                return false;
            }
            return true;
        }

        void OpPgpt()
        {
            if (!MtkReady()) return;
            string cmd = "pgpt" + DaArg();
            StartJob("Check partitions", () => Done(Exec("antumbra.exe", cmd), "Check partitions"), true);
        }

        void OpReadAll()
        {
            if (!MtkReady() || !NeedDir(_tbBackup, "the backup folder")) return;
            string bk = _tbBackup.Text.Trim();
            string cmd = "read-all --skip userdata " + Q(bk) + DaArg();
            StartJob("Read all partitions", () => Done(Exec("antumbra.exe", cmd), "Read all partitions (backup to " + bk + ")"), true);
        }

        void OpRead()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to read") || !NeedDir(_tbBackup, "the backup folder")) return;
            string part = _tbPart.Text.Trim();
            string target = Path.Combine(_tbBackup.Text.Trim(), part + ".bin");
            string cmd = "read " + Q(part) + " " + Q(target) + DaArg();
            StartJob("Read partition " + part, () =>
            {
                Say("  READ partition: \"" + part + "\"");
                Say("  Save as: \"" + target + "\"");
                return Done(Exec("antumbra.exe", cmd), "Read partition " + part);
            }, true);
        }

        void OpWrite()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to write") || !NeedFile(_tbImg, "the image file to write")) return;
            string part = _tbPart.Text.Trim();
            string img = _tbImg.Text.Trim();
            if (!Confirm("WRITE file:\n" + img + "\n\nTO partition: \"" + part + "\"\n\nContinue?")) return;
            string cmd = "write " + Q(part) + " " + Q(img) + DaArg();
            StartJob("Write partition " + part, () => Done(Exec("antumbra.exe", cmd), "Write partition " + part), true);
        }

        void OpErase()
        {
            if (!MtkReady() || !NeedText(_tbPart, "the partition name to erase")) return;
            string part = _tbPart.Text.Trim();
            if (!Confirm("ERASE partition: \"" + part + "\"\n\nThis cannot be undone. Continue?")) return;
            string cmd = "format " + Q(part) + DaArg();
            StartJob("Erase partition " + part, () => Done(Exec("antumbra.exe", cmd), "Erase partition " + part), true);
        }

        void OpReboot()
        {
            if (!MtkReady()) return;
            string cmd = "reboot" + DaArg();
            StartJob("Reboot", () => Done(Exec("antumbra.exe", cmd), "Reboot"), true);
        }

        void OpScatter()
        {
            if (!MtkReady()) return;
            if (!NeedFile(_tbScatter, "the scatter file (.xml)") || !NeedFile(_tbPreloader, "the preloader file (.bin)")) return;
            string scatter = _tbScatter.Text.Trim();
            string pre = _tbPreloader.Text.Trim();
            string da = DaArg();
            string opFile, opTemp;
            if (!OpSplit(scatter, out opFile, out opTemp)) return;
            bool opOnly = (opFile != null);
            string target = opOnly ? opFile : scatter;
            string question = opOnly
                ? "This will FLASH the OP part only - the base is skipped.\n\nScatter: " + target + "\n\nContinue?"
                : "This will FLASH the device.\n\nScatter: " + scatter + "\n\nContinue?";
            if (!Confirm(question))
            {
                if (opTemp != null) TryDelete(opTemp);
                return;
            }
            string tag = opOnly ? " - OP only" : "";
            string cmd = "scatter " + Q(target) + da + " -p " + Q(pre);
            StartJob("Firmware upgrade" + tag, () =>
            {
                int rc = Exec("antumbra.exe", cmd);
                if (opTemp != null) TryDelete(opTemp);
                return Done(rc, "Firmware upgrade" + tag);
            }, true);
        }

        // ---------------------------------------------------------------- OP firmware: flash the OP part only

        static bool IsOpName(string name)
        {
            return Regex.IsMatch("\"" + name + "\"", "open|[^a-zA-Z0-9]op[^a-zA-Z0-9]", RegexOptions.IgnoreCase);
        }

        // Looks for an OP folder (for example Open-Payjoy) inside the scatter folder.
        // false = cancelled. opFile = scatter to flash when "OP only" was chosen. opTemp = temporary scatter to delete afterwards.
        bool OpSplit(string scatter, out string opFile, out string opTemp)
        {
            opFile = null;
            opTemp = null;
            string sdir = Path.GetDirectoryName(scatter);
            if (sdir == null) return true;
            string opDir = null;
            try
            {
                foreach (string d in Directory.GetDirectories(sdir))
                {
                    if (IsOpName(Path.GetFileName(d)))
                    {
                        opDir = d;
                        break;
                    }
                }
            }
            catch (Exception) { }
            Say("");
            if (opDir == null)
            {
                string sname = Path.GetFileName(sdir);
                if (IsOpName(sname)) Say("  OP check : this scatter is inside the OP folder " + sname + " - that is the OP build.");
                else Say("  OP check : no Open / OP folder next to the scatter - normal firmware.");
                return true;
            }
            string opName = Path.GetFileName(opDir);
            int nFiles = 0;
            List<string> scatters = new List<string>();
            try
            {
                nFiles = Directory.GetFiles(opDir).Length;
                foreach (string f in Directory.GetFiles(opDir, "*scatter*.xml", SearchOption.AllDirectories))
                {
                    if (f.IndexOf("_oponly", StringComparison.OrdinalIgnoreCase) < 0) scatters.Add(f);
                }
            }
            catch (Exception) { }
            if (nFiles == 0 && scatters.Count == 0)
            {
                Say("  OP check : the folder " + opName + " has no files - ignored, normal firmware.");
                return true;
            }
            Say("  OP build detected - OP folder: " + opName + "  [" + nFiles + " files]");
            DialogResult dr = MessageBox.Show(this,
                "OP build detected - OP folder: " + opName + "  [" + nFiles + " files]\n\n" +
                "Yes = OP only (flash only the OP part, the base is skipped)\n" +
                "No = Base (normal firmware upgrade)\n" +
                "Cancel = do nothing",
                "OP firmware", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (dr == DialogResult.Cancel) return false;
            if (dr == DialogResult.No) return true;
            if (scatters.Count == 1)
            {
                opFile = scatters[0];
            }
            else if (scatters.Count > 1)
            {
                string pick = PickFromList("More than one scatter was found in the OP folder", scatters);
                if (pick == null) return false;
                opFile = pick;
            }
            else
            {
                // no scatter in the OP folder: build a copy of the base scatter that flashes only the images found in the OP folder
                string dst = Path.Combine(opDir, Path.GetFileNameWithoutExtension(scatter) + "_oponly" + Path.GetExtension(scatter));
                TryDelete(dst);
                if (!BuildOpOnly(scatter, opDir, dst))
                {
                    Say("");
                    Say("  Nothing was changed - the OP-only list could not be built.");
                    return false;
                }
                opFile = dst;
                opTemp = dst;
            }
            Say("  OP scatter : " + opFile);
            return true;
        }

        string PickFromList(string title, List<string> items)
        {
            using (Form f = new Form())
            {
                f.Text = title;
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(720, 280);
                f.BackColor = _t.Bg;
                f.ForeColor = _t.Fg;
                ListBox lb = new ListBox();
                lb.Dock = DockStyle.Fill;
                lb.BackColor = _t.Input;
                lb.ForeColor = _t.Fg;
                lb.BorderStyle = BorderStyle.None;
                foreach (string it in items) lb.Items.Add(it);
                lb.SelectedIndex = 0;
                Panel bar = new Panel();
                bar.Dock = DockStyle.Bottom;
                bar.Height = 46;
                Button ok = new Button();
                ok.Text = "Flash this scatter";
                ok.DialogResult = DialogResult.OK;
                ok.SetBounds(440, 9, 160, 28);
                Button cancel = new Button();
                cancel.Text = "Cancel";
                cancel.DialogResult = DialogResult.Cancel;
                cancel.SetBounds(610, 9, 96, 28);
                bar.Controls.Add(ok);
                bar.Controls.Add(cancel);
                f.Controls.Add(lb);
                f.Controls.Add(bar);
                f.AcceptButton = ok;
                f.CancelButton = cancel;
                if (f.ShowDialog(this) == DialogResult.OK && lb.SelectedIndex >= 0) return (string)lb.SelectedItem;
            }
            return null;
        }

        static string SetFile(string l, string v)
        {
            v = v.Replace("$", "$$");
            l = Regex.Replace(l, @"(file_name\s*:\s*)\S+", "${1}" + v, RegexOptions.IgnoreCase);
            l = Regex.Replace(l, @"(<file_name>\s*)[^<]*?(\s*</file_name>)", "${1}" + v + "${2}", RegexOptions.IgnoreCase);
            l = Regex.Replace(l, @"(file_name\s*=\s*"")[^""]*("")", "${1}" + v + "${2}", RegexOptions.IgnoreCase);
            return l;
        }

        static string SetOff(string l)
        {
            return Regex.Replace(l, @"(is_download(?:\s*[:=]\s*""?|>\s*))(true|1|yes)", "${1}false", RegexOptions.IgnoreCase);
        }

        // Writes a copy of the scatter that downloads only the images present in the OP folder.
        bool BuildOpOnly(string src, string opdir, string dst)
        {
            try
            {
                string text = File.ReadAllText(src);
                string nl = text.IndexOf("\r\n", StringComparison.Ordinal) >= 0 ? "\r\n" : "\n";
                string[] lines = Regex.Split(text, "\r?\n");
                Regex rxName = new Regex(@"partition_name(?:\s*[:=]\s*""?|>\s*)([^\s""<]+)", RegexOptions.IgnoreCase);
                Regex rxFile = new Regex(@"file_name(?:\s*[:=]\s*""?|>\s*)([^\s""<]+)", RegexOptions.IgnoreCase);
                Regex rxDl = new Regex(@"is_download(?:\s*[:=]\s*""?|>\s*)(true|false|1|0|yes|no)", RegexOptions.IgnoreCase);
                List<Part> parts = new List<Part>();
                Part cur = null;
                for (int i = 0; i < lines.Length; i++)
                {
                    Match m = rxName.Match(lines[i]);
                    if (m.Success)
                    {
                        cur = new Part();
                        cur.Name = m.Groups[1].Value;
                        parts.Add(cur);
                    }
                    if (cur == null) continue;
                    m = rxFile.Match(lines[i]);
                    if (m.Success && cur.FileLine < 0)
                    {
                        cur.Img = m.Groups[1].Value;
                        cur.FileLine = i;
                    }
                    m = rxDl.Match(lines[i]);
                    if (m.Success && cur.DlLine < 0)
                    {
                        cur.Dl = Regex.IsMatch(m.Groups[1].Value, "^(true|1|yes)$", RegexOptions.IgnoreCase);
                        cur.DlLine = i;
                    }
                }
                Dictionary<string, string> opfiles = new Dictionary<string, string>();
                foreach (string f in Directory.GetFiles(opdir))
                {
                    opfiles[Path.GetFileName(f).ToLowerInvariant()] = Path.GetFileName(f);
                }
                List<Part> keep = new List<Part>();
                List<Part> skip = new List<Part>();
                int actN = 0;
                foreach (Part p in parts)
                {
                    if (!(p.Dl && p.Img != "" && p.Img != "NONE")) continue;
                    actN++;
                    string key = Path.GetFileName(p.Img).ToLowerInvariant();
                    string real;
                    if (opfiles.TryGetValue(key, out real))
                    {
                        p.OpName = real;
                        keep.Add(p);
                    }
                    else
                    {
                        skip.Add(p);
                    }
                }
                if (actN < 3)
                {
                    Say("  Could not read the partition list from the scatter.");
                    return false;
                }
                if (keep.Count == 0)
                {
                    Say("  None of the " + actN + " images listed in the scatter were found in the OP folder.");
                    Say("  Files in the OP folder:");
                    int shown = 0;
                    foreach (string f2 in Directory.GetFiles(opdir))
                    {
                        if (shown++ >= 25) break;
                        Say("    " + Path.GetFileName(f2));
                    }
                    Say("  Images the scatter lists:");
                    shown = 0;
                    foreach (Part p2 in skip)
                    {
                        if (shown++ >= 25) break;
                        Say("    " + p2.Img);
                    }
                    return false;
                }
                List<string> outl = new List<string>(lines);
                foreach (Part p3 in keep)
                {
                    if (p3.FileLine >= 0) outl[p3.FileLine] = SetFile(outl[p3.FileLine], p3.OpName);
                }
                foreach (Part p4 in skip)
                {
                    if (p4.DlLine >= 0) outl[p4.DlLine] = SetOff(outl[p4.DlLine]);
                    if (p4.FileLine >= 0) outl[p4.FileLine] = SetFile(outl[p4.FileLine], "NONE");
                }
                File.WriteAllText(dst, string.Join(nl, outl.ToArray()), new UTF8Encoding(false));
                List<string> names = new List<string>();
                foreach (Part p5 in keep) names.Add(p5.Name);
                Say("  OP folder : " + opdir);
                Say("  Will flash " + keep.Count + " partitions from the OP folder:");
                Say("    " + string.Join(", ", names.ToArray()));
                Say("  Skipped    " + skip.Count + " base partitions");
                return true;
            }
            catch (Exception ex)
            {
                Say("  Error: " + ex.Message);
                return false;
            }
        }

